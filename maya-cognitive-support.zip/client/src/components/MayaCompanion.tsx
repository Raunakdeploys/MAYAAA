import { useAuth } from "@/_core/hooks/useAuth";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Mic, MicOff, Sparkles, Volume2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

type CompanionProps = { onBack: () => void; patientId?: number };
type SpeechRecognitionInstance = { start: () => void; stop: () => void; lang: string; continuous: boolean; interimResults: boolean; onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null; onerror: (() => void) | null; onend: (() => void) | null };
type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance;

function speak(text: string) {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.86;
    window.speechSynthesis.speak(utterance);
  }
}

export default function MayaCompanion({ onBack, patientId }: CompanionProps) {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const history = trpc.maya.assistantHistory.useQuery({ patientId: patientId ?? 0 }, { enabled: Boolean(isAuthenticated && patientId), retry: false });
  const chat = trpc.maya.assistantChat.useMutation();
  const [listening, setListening] = useState(false);
  const messages = useMemo<Message[]>(() => (history.data ?? []).slice().reverse().map(message => ({ role: message.role, content: message.content })), [history.data]);
  const send = async (content: string) => {
    if (!patientId || !isAuthenticated) { startLogin(); return; }
    try {
      await chat.mutateAsync({ patientId, message: content });
      await utils.maya.assistantHistory.invalidate({ patientId });
    } catch { toast.error("MAYA could not reply just now. You can try again when the connection returns."); }
  };
  const useVoice = () => {
    const recognition = (window as unknown as { SpeechRecognition?: SpeechRecognitionConstructor; webkitSpeechRecognition?: SpeechRecognitionConstructor }).SpeechRecognition
      ?? (window as unknown as { webkitSpeechRecognition?: SpeechRecognitionConstructor }).webkitSpeechRecognition;
    if (!recognition) { toast.message("Voice typing is not available in this browser. You can type your message instead."); return; }
    const session = new recognition();
    session.lang = "en-IN"; session.continuous = false; session.interimResults = false;
    session.onresult = event => { const transcript = event.results[0]?.[0]?.transcript?.trim(); if (transcript) void send(transcript); };
    session.onerror = () => toast.message("MAYA could not hear that. You can try again or type your message.");
    session.onend = () => setListening(false);
    setListening(true); session.start();
  };
  if (!isAuthenticated || !patientId) return <section className="companion-shell"><button className="play-back" onClick={onBack}><ArrowLeft size={17} /> Back to home</button><div className="companion-locked"><Sparkles size={32} /><h1>Ask MAYA together.</h1><p>The companion uses only caregiver-approved routine details. Sign in and save a familiar world before starting a private conversation.</p><button className="play-primary" onClick={startLogin}>Sign in to begin</button></div></section>;
  if (history.error) return <section className="companion-shell"><button className="play-back" onClick={onBack}><ArrowLeft size={17} /> Back to home</button><div className="companion-locked"><Sparkles size={32} /><h1>Your private conversation needs a moment.</h1><p>MAYA could not open the saved messages. Nothing has been changed, and you can try again before starting a new conversation.</p><button className="play-primary" onClick={() => void history.refetch()}>Try again</button></div></section>;
  return <section className="companion-shell"><button className="play-back" onClick={onBack}><ArrowLeft size={17} /> Back to home</button><header className="companion-header"><div><p className="eyebrow">MAYA companion</p><h1>A gentle question is welcome.</h1><p>Ask for an instruction again, a game hint, or a calm pause. MAYA only uses the routine details your caregiver approved.</p></div><button className="listen-orb" onClick={() => { const last = [...messages].reverse().find(message => message.role === "assistant"); speak(last?.content ?? "I am here with you. We can take one small familiar step."); }} aria-label="Listen to the latest MAYA response"><Volume2 size={19} /></button></header><div className="companion-actions"><button onClick={useVoice} disabled={listening || chat.isPending}>{listening ? <MicOff size={17} /> : <Mic size={17} />}{listening ? "Listening…" : "Speak to MAYA"}</button><span>Voice typing opens only when you tap this button.</span></div><AIChatBox messages={messages} onSendMessage={(content) => void send(content)} isLoading={history.isLoading || chat.isPending} height="440px" placeholder="For example: Can you repeat the next step?" emptyStateMessage="MAYA is ready to help with one familiar step." suggestedPrompts={["Please repeat my next step.", "Can you give me a gentle game hint?", "I would like a calm pause."]} /></section>;
}
