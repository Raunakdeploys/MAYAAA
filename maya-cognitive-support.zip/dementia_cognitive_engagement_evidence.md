# MAYA Evidence Brief: Cognitive Engagement, Not a Medical Claim

## Executive interpretation

MAYA is designed as a **personalised cognitive-stimulation and engagement tool** for people living with dementia. Its games are intended to encourage enjoyable participation, familiar conversation, routine, and caregiver-supported choice. MAYA **does not diagnose dementia, measure disease severity, predict decline, claim to restore memory, or promise an individual cognitive benefit**.

> **Important distinction:** Research results from structured cognitive-stimulation and cognitive-training programmes cannot be converted into a personal “brain score,” a disease-progression claim, or a guaranteed outcome from a digital app.

## What the evidence says

| Research area | Quantitative finding | What MAYA can responsibly use | What MAYA must not claim |
|---|---:|---|---|
| Cognitive stimulation | A 2023 Cochrane review included **37 RCTs and 2,766 participants**. It reported a small post-programme cognitive benefit versus usual care/unstructured activity (**SMD 0.40; 95% CI 0.25–0.55**) and found the studies were heterogeneous. [1] | Varied, enjoyable activities; gentle social and familiar-content prompts; regular caregiver-supported participation. | That MAYA improves cognition for a particular person, prevents decline, or substitutes for clinical care. |
| Communication and social interaction | The same review reported an increase in staff/interviewer-rated communication and social interaction in **7 studies / 702 participants** (**SMD 0.53; 95% CI 0.36–0.70**). [1] | Voice support, shared caregiver context, Family Radio, Story Garden, and prompts that can invite conversation. | That an app will improve relationships or communication for every person. |
| Cognitive training | A 2019 Cochrane review included **33 trials**. Against control conditions, the end-of-treatment global-cognition composite result was **SMD 0.42 (95% CI 0.23–0.62)**; many other outcomes had low or very-low certainty. [2] | Structured, clearly scoped game activities with transparent difficulty and support choices. | That harder levels are medical therapy, or that a score diagnoses or tracks dementia progression. |
| Individual digital delivery | The cognitive-stimulation review states that most evidence concerned group programmes, with comparatively few studies of individual stimulation; it identifies an evidence gap for digital, remote, and individual delivery. [1] | Build for usability, dignity, consent, and caregiver-guided adaptation; collect product-engagement data separately from health outcomes. | That MAYA’s individual digital delivery has the same clinical effect as the reviewed group programmes. |

## How the evidence shaped MAYA

MAYA’s six worlds are purposefully varied: **Memory Mosaic, Lantern Echo, Routine Studio, Market Detective, Story Garden, and Village Navigator**. This reflects the broad, enjoyable activity approach used in cognitive stimulation rather than an isolated memory test. Every game has twenty standard levels, no countdown, a visible pause route, spoken cues, familiar caregiver-approved content, and no points deducted for a difficult response.

The adaptive system is a **comfort algorithm**, not an assessment algorithm. After repeated support needs near a level boundary, it offers a bridge activity between two nearby levels. It records the chosen support, completed moment, and activity world; it does not create a cognitive-health score, disease label, or risk prediction.

## Progress measures shown to caregivers

| MAYA shows | Why it is useful | MAYA deliberately does not show |
|---|---|---|
| Completed moments, selected activity worlds, requested support, pauses, caregiver-approved content, and available bridge practice | Supports practical, respectful adjustment of the next activity and creates a transparent care conversation. | “Brain age,” dementia stage, decline forecast, clinical risk, diagnostic trend, comparative ranking, or treatment response. |
| Participation points | A lightweight in-game acknowledgement of completed moments. | A health score or a measure of intelligence, recovery, or independence. |
| Recent game interaction | Helps a caregiver notice preferences and whether a simpler version may feel more comfortable. | Proof that a person has improved or deteriorated cognitively. |

## Safe presentation language

During a hackathon presentation, describe MAYA as follows:

> “MAYA turns caregiver-approved routines, objects, places, and stories into accessible cognitive-engagement activities. It uses transparent adaptive support to keep a challenge comfortable, and it gives caregivers private engagement context rather than a diagnosis.”

Avoid saying that MAYA “trains the brain,” “makes memory stronger,” “slows dementia,” “detects decline,” or “improves cognitive ability.” Those outcomes require appropriately designed clinical research and should not be inferred from product usage.

## References

[1] Woods B, Rai HK, Elliott E, et al. [*Cognitive stimulation to improve cognitive functioning in people with dementia*](https://pmc.ncbi.nlm.nih.gov/articles/PMC9891430/). *Cochrane Database of Systematic Reviews*. 2023;1:CD005562.  

[2] Bahar-Fuchs A, Martyr A, Goh AMY, et al. [*Cognitive training for people with mild to moderate dementia*](https://pmc.ncbi.nlm.nih.gov/articles/PMC6433473/). *Cochrane Database of Systematic Reviews*. 2019;3:CD013069.  

[3] Alzheimer's Society. [*Why is digital design important for someone affected by dementia?*](https://www.alzheimers.org.uk/blog/how-design-website-someone-affected-dementia). 2024.  

[4] AbilityNet. [*Designing for Dementia*](https://abilitynet.org.uk/factsheets/designing-dementia). 2025.
