import { beforeEach, describe, expect, it, vi } from "vitest";

const mock = vi.hoisted(() => {
  const state: { progress: Record<string, unknown> | null; sessions: Record<string, unknown>[]; activities: Record<string, unknown>[]; assistantMessages: Record<string, unknown>[]; cameraChallenges: Record<string, unknown>[]; recommendations: Record<string, unknown>[]; contentCards: Record<string, unknown>[]; domainEngagement: Record<string, unknown>[] } = { progress: null, sessions: [], activities: [], assistantMessages: [], cameraChallenges: [], recommendations: [], contentCards: [], domainEngagement: [] };
  const patient = { id: 51, caregiverId: 9, preferredName: "Aita", preferredLanguage: "Assamese", isArchived: false, updatedAt: new Date() };
  const tableName = (table: unknown) => (table as Record<symbol, string>)[Symbol.for("drizzle:Name")];
  const rowsFor = (table: unknown) => {
    switch (tableName(table)) {
      case "patients": return [patient];
      case "gameProgress": return state.progress ? [state.progress] : [];
      case "gameSessions": return state.sessions;
      case "activityEvents": return state.activities;
      case "assistantMessages": return [...state.assistantMessages].reverse();
      case "cameraChallenges": return state.cameraChallenges;
      case "adaptiveGameRecommendations": return state.recommendations;
      case "gameContentCards": return state.contentCards;
      case "domainEngagement": return state.domainEngagement;
      default: return [];
    }
  };
  const queryFor = (table: unknown) => {
    const query = {
      where: vi.fn(() => query),
      orderBy: vi.fn(() => query),
      limit: vi.fn(async (count: number) => rowsFor(table).slice(0, count)),
      then: (resolve: (value: Record<string, unknown>[]) => unknown) => Promise.resolve(rowsFor(table)).then(resolve),
    };
    return query;
  };
  const db = {
    select: vi.fn(() => ({ from: vi.fn((table: unknown) => queryFor(table)) })),
    insert: vi.fn((table: unknown) => ({ values: vi.fn((values: Record<string, unknown>) => {
      const name = tableName(table);
      if (name === "gameProgress") state.progress = { id: 7, ...values };
      if (name === "gameSessions") state.sessions.push({ id: state.sessions.length + 1, ...values });
      if (name === "activityEvents") state.activities.push({ id: state.activities.length + 1, ...values });
      if (name === "assistantMessages") state.assistantMessages.push({ id: state.assistantMessages.length + 1, ...values });
      if (name === "adaptiveGameRecommendations") state.recommendations.push({ id: state.recommendations.length + 1, ...values });
      if (name === "gameContentCards") state.contentCards.push({ id: state.contentCards.length + 1, ...values });
      if (name === "domainEngagement") state.domainEngagement.push({ id: state.domainEngagement.length + 1, ...values });
      return { $returningId: async () => [{ id: 7 }] };
    }) })),
    update: vi.fn((table: unknown) => ({ set: vi.fn((values: Record<string, unknown>) => ({ where: vi.fn(async () => {
      if (tableName(table) === "adaptiveGameRecommendations") {
        const target = state.recommendations.find(item => item.id === 99);
        if (target) Object.assign(target, values);
      }
    }) })) })),
  };
  return { db, state };
});

vi.mock("drizzle-orm/mysql2", () => ({ drizzle: () => mock.db }));

import { appendMayaAssistantMessage, getMayaAssistantHistory, getMayaPlayroom, recordMayaGameSession } from "./db";
import { GAME_CATALOG } from "../shared/games";
import { createRepresentativeCompletion } from "../shared/gameCompletion";

describe("MAYA game session persistence", () => {
  beforeEach(() => {
    mock.state.progress = null;
    mock.state.sessions = [];
    mock.state.activities = [];
    mock.state.assistantMessages = [];
    mock.state.cameraChallenges = [];
    mock.state.recommendations = [];
    mock.state.contentCards = [];
    mock.state.domainEngagement = [];
    process.env.DATABASE_URL = "mock://maya-game-session-test";
  });

  it("persists a confident session and returns refreshed Playroom progress", async () => {
    const result = await recordMayaGameSession(9, {
      patientId: 51, gameId: "pairing_table", level: 2,
      correctCount: 3, totalItems: 3, hintsUsed: 0, completed: true, durationSeconds: 38,
    });

    const savedGame = result.playroom.games.find(game => game.id === "pairing_table");
    expect(result.outcome.pointsEarned).toBeGreaterThan(0);
    expect(savedGame?.progress.unlockedLevel).toBe(3);
    expect(savedGame?.progress.memoryPoints).toBe(result.outcome.pointsEarned);
    expect(mock.state.sessions).toHaveLength(1);
  });

  it("saves a representative completion for every game and refreshes the corresponding game shelf", async () => {
    for (const game of GAME_CATALOG) {
      mock.state.progress = null;
      mock.state.sessions = [];
      mock.state.activities = [];
      mock.state.assistantMessages = [];
      mock.state.cameraChallenges = [];
      mock.state.recommendations = [];
      mock.state.contentCards = [];
      mock.state.domainEngagement = [];
      const completion = createRepresentativeCompletion(game.id, 5);
      const result = await recordMayaGameSession(9, {
        patientId: 51,
        gameId: completion.gameId,
        level: completion.level,
        correctCount: completion.correctCount,
        totalItems: completion.totalItems,
        hintsUsed: completion.hintsUsed,
        completed: true,
        durationSeconds: 45,
      });
      const refreshed = result.playroom.games.find(item => item.id === game.id);
      expect(refreshed?.progress.totalSessions).toBe(1);
      expect(refreshed?.progress.memoryPoints).toBe(result.outcome.pointsEarned);
      expect(mock.state.sessions[0]?.gameId).toBe(game.id);
    }
  });

  it("persists assistant messages and returns a fresh private history in newest-first order", async () => {
    await appendMayaAssistantMessage(9, 51, "user", "Please repeat the next step.");
    await appendMayaAssistantMessage(9, 51, "assistant", "Let us begin with a glass of water.");
    const history = await getMayaAssistantHistory(9, 51);
    expect(history).toHaveLength(2);
    expect(history[0]?.role).toBe("assistant");
    expect(history[1]?.role).toBe("user");
  });

  it("includes every persisted Photo Quest award in the points total, even after the recent display window", async () => {
    mock.state.cameraChallenges = Array.from({ length: 10 }, (_, index) => ({ id: index + 1, patientId: 51, caregiverId: 9, awardedPoints: 12, targetKeywords: "[\"mango\"]" }));
    const playroom = await getMayaPlayroom(9);
    expect(playroom.photoChallenges).toHaveLength(8);
    expect(playroom.photoQuestMemoryPoints).toBe(120);
    expect(playroom.totalMemoryPoints).toBe(120);
  });

  it("saves an explainable adaptive recommendation with every game moment", async () => {
    await recordMayaGameSession(9, { patientId: 51, gameId: "daily_order", level: 4, correctCount: 4, totalItems: 4, hintsUsed: 0, completed: true, durationSeconds: 51, sessionKind: "standard", contentSource: "caregiver_approved", comfortChoice: "steady" });
    expect(mock.state.recommendations).toHaveLength(1);
    expect(mock.state.recommendations[0]).toMatchObject({ gameId: "daily_order", kind: "advance", currentLevel: 4, recommendedLevel: 5 });
    expect(mock.state.sessions[0]).toMatchObject({ sessionKind: "standard", contentSource: "caregiver_approved", comfortChoice: "steady" });
  });

  it("persists domain engagement for each of the six genres without creating a clinical score", async () => {
    for (const game of GAME_CATALOG) {
      mock.state.progress = null;
      await recordMayaGameSession(9, { patientId: 51, gameId: game.id, level: 1, correctCount: 2, totalItems: 2, hintsUsed: 1, completed: true, durationSeconds: 40, comfortChoice: "needed_support" });
    }
    expect(mock.state.domainEngagement).toHaveLength(6);
    expect(mock.state.domainEngagement.map(item => item.domain)).toEqual(expect.arrayContaining(["visual_association", "working_memory", "routine_planning", "selective_attention", "language_reminiscence", "spatial_orientation"]));
    mock.state.domainEngagement.forEach(item => expect(item).toMatchObject({ momentsCompleted: 1, momentsWithSupport: 1 }));
  });

  it("resolves a completed bridge recommendation so it is not offered again as available", async () => {
    mock.state.recommendations = [{ id: 99, patientId: 51, gameId: "lantern_path", kind: "bridge_assessment", currentLevel: 5, recommendedLevel: 4, lowerLevel: 4, upperLevel: 5, status: "available", createdAt: new Date() }];
    const result = await recordMayaGameSession(9, { patientId: 51, gameId: "lantern_path", level: 4, correctCount: 3, totalItems: 3, hintsUsed: 1, completed: true, durationSeconds: 52, sessionKind: "bridge_assessment", comfortChoice: "needed_support" });
    expect(mock.state.recommendations.find(item => item.id === 99)).toMatchObject({ status: "completed" });
    expect(result.playroom.adaptiveRecommendations.some(item => item.kind === "bridge_assessment" && item.status === "available")).toBe(false);
  });
});
