import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * A patient profile belongs to exactly one authenticated caregiver account.
 * The profile deliberately stores only the personal details required to create
 * familiar, caregiver-approved sessions; it does not store a medical diagnosis.
 */
export const patients = mysqlTable("patients", {
  id: int("id").autoincrement().primaryKey(),
  caregiverId: int("caregiverId").notNull(),
  preferredName: varchar("preferredName", { length: 120 }).notNull(),
  preferredLanguage: varchar("preferredLanguage", { length: 48 }).notNull().default("English"),
  consentStatus: mysqlEnum("consentStatus", ["pending", "confirmed", "withdrawn"]).notNull().default("pending"),
  isArchived: boolean("isArchived").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("patients_caregiver_idx").on(table.caregiverId)]);

/**
 * The currently approved home routine for a patient. Content remains structured
 * but text-based so it can be carefully reviewed by a caregiver before use.
 */
export const patientRoutines = mysqlTable("patientRoutines", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  morningRoutine: text("morningRoutine").notNull(),
  medicineLocation: varchar("medicineLocation", { length: 255 }).notNull(),
  approvedContent: text("approvedContent").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("patient_routines_patient_idx").on(table.patientId)]);

/**
 * An immutable activity record supports the caregiver’s engagement view without
 * framing it as a clinical score. All timestamps are persisted in UTC.
 */
export const activityEvents = mysqlTable("activityEvents", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  gameId: varchar("gameId", { length: 80 }).notNull(),
  templateId: varchar("templateId", { length: 80 }).notNull(),
  level: int("level").notNull(),
  language: varchar("language", { length: 48 }).notNull(),
  completed: boolean("completed").notNull().default(false),
  accuracyPercent: int("accuracyPercent").notNull().default(0),
  hintsUsed: int("hintsUsed").notNull().default(0),
  responseTimeSeconds: int("responseTimeSeconds").notNull().default(0),
  frustrationFlag: boolean("frustrationFlag").notNull().default(false),
  mood: varchar("mood", { length: 32 }).notNull().default("calm"),
  syncStatus: mysqlEnum("syncStatus", ["pending", "synced"]).notNull().default("synced"),
  occurredAt: timestamp("occurredAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("activity_events_patient_occurred_idx").on(table.patientId, table.occurredAt)]);

/**
 * Caregiver-owned support notes preserve non-diagnostic follow-up context and
 * make review acknowledgement durable across devices.
 */
export const supportNotes = mysqlTable("supportNotes", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  authorId: int("authorId").notNull(),
  kind: mysqlEnum("kind", ["check_in", "care_note"]).notNull().default("check_in"),
  body: text("body").notNull(),
  reviewed: boolean("reviewed").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
}, (table) => [index("support_notes_patient_idx").on(table.patientId)]);

/**
 * One durable progress row per game and patient. Points represent completed
 * moments, never a health score or assessment result.
 */
export const gameProgress = mysqlTable("gameProgress", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  gameId: varchar("gameId", { length: 80 }).notNull(),
  unlockedLevel: int("unlockedLevel").notNull().default(1),
  highestLevel: int("highestLevel").notNull().default(1),
  memoryPoints: int("memoryPoints").notNull().default(0),
  totalSessions: int("totalSessions").notNull().default(0),
  completedSessions: int("completedSessions").notNull().default(0),
  consecutiveStruggles: int("consecutiveStruggles").notNull().default(0),
  recommendedLevel: int("recommendedLevel"),
  recommendationKind: mysqlEnum("recommendationKind", ["advance", "repeat_with_new_content", "bridge_assessment", "gentler_choice"]),
  lastComfortBand: varchar("lastComfortBand", { length: 48 }),
  lastPlayedAt: timestamp("lastPlayedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("game_progress_patient_game_idx").on(table.patientId, table.gameId)]);

/** Immutable game outcome data for a caregiver’s engagement history. */
export const gameSessions = mysqlTable("gameSessions", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  gameId: varchar("gameId", { length: 80 }).notNull(),
  level: int("level").notNull(),
  score: int("score").notNull().default(0),
  possiblePoints: int("possiblePoints").notNull().default(0),
  correctCount: int("correctCount").notNull().default(0),
  totalItems: int("totalItems").notNull().default(0),
  hintsUsed: int("hintsUsed").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  durationSeconds: int("durationSeconds").notNull().default(0),
  pointsEarned: int("pointsEarned").notNull().default(0),
  sessionKind: mysqlEnum("sessionKind", ["standard", "bridge_assessment"]).notNull().default("standard"),
  contentSource: mysqlEnum("contentSource", ["caregiver_approved", "general"]).notNull().default("general"),
  comfortChoice: mysqlEnum("comfortChoice", ["steady", "needed_support", "prefer_gentler", "stopped_early"]).notNull().default("steady"),
  occurredAt: timestamp("occurredAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("game_sessions_patient_occurred_idx").on(table.patientId, table.occurredAt)]);

/** Caregiver-approved labels for a person's personalised game content. */
export const gameContentCards = mysqlTable("gameContentCards", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  caregiverId: int("caregiverId").notNull(),
  category: mysqlEnum("category", ["person", "place", "object", "food", "routine", "saying", "sound"]).notNull(),
  label: varchar("label", { length: 120 }).notNull(),
  language: varchar("language", { length: 48 }).notNull().default("English"),
  isActive: boolean("isActive").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("game_content_cards_patient_category_idx").on(table.patientId, table.category)]);

/**
 * A transparent adaptive recommendation. This records a suggested game
 * experience only; it is never a diagnosis, prognosis, or health assessment.
 */
export const adaptiveGameRecommendations = mysqlTable("adaptiveGameRecommendations", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  gameId: varchar("gameId", { length: 80 }).notNull(),
  kind: mysqlEnum("kind", ["advance", "repeat_with_new_content", "bridge_assessment", "gentler_choice"]).notNull(),
  currentLevel: int("currentLevel").notNull(),
  recommendedLevel: int("recommendedLevel").notNull(),
  lowerLevel: int("lowerLevel"),
  upperLevel: int("upperLevel"),
  difficultyRatioPercent: int("difficultyRatioPercent"),
  reason: varchar("reason", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["available", "started", "completed", "dismissed"]).notNull().default("available"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
}, (table) => [index("adaptive_recommendations_patient_game_idx").on(table.patientId, table.gameId)]);

/**
 * Aggregated engagement by game domain. These are interaction summaries only,
 * never cognitive test results, health scores, or diagnostic measures.
 */
export const domainEngagement = mysqlTable("domainEngagement", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  domain: mysqlEnum("domain", ["visual_association", "working_memory", "routine_planning", "selective_attention", "language_reminiscence", "spatial_orientation"]).notNull(),
  momentsCompleted: int("momentsCompleted").notNull().default(0),
  momentsWithSupport: int("momentsWithSupport").notNull().default(0),
  totalParticipationPoints: int("totalParticipationPoints").notNull().default(0),
  lastEngagedAt: timestamp("lastEngagedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("domain_engagement_patient_domain_idx").on(table.patientId, table.domain)]);

/**
 * Photo Quest retains the caregiver-approved prompt and result by default, not
 * the captured image. Images are never used for facial recognition.
 */
export const cameraChallenges = mysqlTable("cameraChallenges", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  caregiverId: int("caregiverId").notNull(),
  prompt: varchar("prompt", { length: 160 }).notNull(),
  targetKeywords: text("targetKeywords").notNull(),
  status: mysqlEnum("status", ["pending", "verified", "needs_retake", "declined"]).notNull().default("pending"),
  confidencePercent: int("confidencePercent").notNull().default(0),
  awardedPoints: int("awardedPoints").notNull().default(0),
  imageStored: boolean("imageStored").notNull().default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
}, (table) => [index("camera_challenges_patient_created_idx").on(table.patientId, table.createdAt)]);

/** Short, caregiver-scoped assistant messages for continuity between visits. */
export const assistantMessages = mysqlTable("assistantMessages", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  caregiverId: int("caregiverId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("assistant_messages_patient_created_idx").on(table.patientId, table.createdAt)]);

export type Patient = typeof patients.$inferSelect;
export type InsertPatient = typeof patients.$inferInsert;
export type PatientRoutine = typeof patientRoutines.$inferSelect;
export type InsertPatientRoutine = typeof patientRoutines.$inferInsert;
export type ActivityEvent = typeof activityEvents.$inferSelect;
export type InsertActivityEvent = typeof activityEvents.$inferInsert;
export type SupportNote = typeof supportNotes.$inferSelect;
export type InsertSupportNote = typeof supportNotes.$inferInsert;
export type GameProgress = typeof gameProgress.$inferSelect;
export type InsertGameProgress = typeof gameProgress.$inferInsert;
export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = typeof gameSessions.$inferInsert;
export type GameContentCard = typeof gameContentCards.$inferSelect;
export type InsertGameContentCard = typeof gameContentCards.$inferInsert;
export type AdaptiveGameRecommendation = typeof adaptiveGameRecommendations.$inferSelect;
export type InsertAdaptiveGameRecommendation = typeof adaptiveGameRecommendations.$inferInsert;
export type DomainEngagement = typeof domainEngagement.$inferSelect;
export type InsertDomainEngagement = typeof domainEngagement.$inferInsert;
export type CameraChallenge = typeof cameraChallenges.$inferSelect;
export type InsertCameraChallenge = typeof cameraChallenges.$inferInsert;
export type AssistantMessage = typeof assistantMessages.$inferSelect;
export type InsertAssistantMessage = typeof assistantMessages.$inferInsert;
