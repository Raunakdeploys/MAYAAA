import { describe, expect, it } from "vitest";
import { calculateGameOutcome, clampLevel, GAME_CATALOG, getGameLevelSpec, MAX_GAME_LEVEL } from "./games";

describe("MAYA Playroom progression rules", () => {
  it("keeps every generated game level inside the ten-level range", () => {
    expect(clampLevel(-3)).toBe(1);
    expect(clampLevel(MAX_GAME_LEVEL + 5)).toBe(MAX_GAME_LEVEL);
  });

  it("advances a confident completion by one gentle step", () => {
    const result = calculateGameOutcome({ level: 4, correctCount: 5, totalItems: 5, hintsUsed: 0, completed: true });
    expect(result.nextUnlockedLevel).toBe(5);
    expect(result.pointsEarned).toBeGreaterThan(0);
  });

  it("does not deduct stored points or force a level drop after a supported attempt", () => {
    const result = calculateGameOutcome({ level: 6, correctCount: 1, totalItems: 4, hintsUsed: 3, completed: true });
    expect(result.nextUnlockedLevel).toBe(6);
    expect(result.pointsEarned).toBeGreaterThanOrEqual(0);
  });

  it("defines six distinct games and produces safe progression for every level from one through ten", () => {
    expect(GAME_CATALOG).toHaveLength(6);
    expect(new Set(GAME_CATALOG.map(game => game.id)).size).toBe(6);
    for (const game of GAME_CATALOG) {
      for (let level = 1; level <= MAX_GAME_LEVEL; level += 1) {
        const outcome = calculateGameOutcome({ level, correctCount: 1, totalItems: 1, hintsUsed: 0, completed: true });
        expect(outcome.nextUnlockedLevel).toBeGreaterThanOrEqual(level);
        expect(outcome.nextUnlockedLevel).toBeLessThanOrEqual(MAX_GAME_LEVEL);
      }
    }
  });

  it("scales each game’s own visible challenge configuration across low, middle, and high levels", () => {
    const expected = {
      pairing_table: [2, 4, 6], lantern_path: [3, 5, 7], daily_order: [2, 4, 6],
      market_basket: [1, 2, 4], word_garden: [2, 3, 4], village_map: [4, 6, 9],
    } as const;
    for (const game of GAME_CATALOG) {
      const scales = [1, 5, 10].map(level => getGameLevelSpec(game.id, level).primaryCount);
      expect(scales).toEqual(expected[game.id]);
    }
  });
});
