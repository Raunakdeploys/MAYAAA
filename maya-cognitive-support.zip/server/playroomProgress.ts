import { calculateGameOutcome, type ProgressRuleInput } from "../shared/games";
import { getAdvancedLevelSpec, recommendNextAdaptiveExperience, type AdaptiveRecommendation } from "../shared/advancedGames";
import type { GameId } from "../shared/games";

export type StoredProgress = {
  unlockedLevel: number;
  highestLevel: number;
  memoryPoints: number;
  totalSessions: number;
  completedSessions: number;
  consecutiveStruggles?: number;
  recommendedLevel?: number | null;
  recommendationKind?: "advance" | "repeat_with_new_content" | "bridge_assessment" | "gentler_choice" | null;
  lastComfortBand?: string | null;
};

export function resolvePlayroomProgress(previous: StoredProgress | undefined, input: ProgressRuleInput & { gameId?: GameId; comfortChoice?: "steady" | "needed_support" | "prefer_gentler" | "stopped_early" }) {
  const outcome = calculateGameOutcome(input);
  const gameId = input.gameId ?? "pairing_table";
  const struggledThisSession = input.comfortChoice === "prefer_gentler" || input.comfortChoice === "stopped_early" || input.hintsUsed >= 2 || outcome.accuracyPercent < 60;
  const consecutiveStruggles = struggledThisSession ? (previous?.consecutiveStruggles ?? 0) + 1 : 0;
  const recommendation = recommendNextAdaptiveExperience({ level: input.level, accuracyPercent: outcome.accuracyPercent, hintsUsed: input.hintsUsed, completed: input.completed, consecutiveStruggles });
  const standardRecommendationLevel = recommendation.kind === "bridge_assessment" ? recommendation.upperLevel : recommendation.nextLevel;
  return {
    outcome,
    recommendation,
    next: {
      unlockedLevel: Math.max(previous?.unlockedLevel ?? 1, outcome.nextUnlockedLevel, standardRecommendationLevel),
      highestLevel: Math.max(previous?.highestLevel ?? 1, input.level),
      memoryPoints: (previous?.memoryPoints ?? 0) + outcome.pointsEarned,
      totalSessions: (previous?.totalSessions ?? 0) + 1,
      completedSessions: (previous?.completedSessions ?? 0) + (input.completed ? 1 : 0),
      consecutiveStruggles,
      recommendedLevel: recommendation.kind === "bridge_assessment" ? recommendation.lowerLevel : recommendation.nextLevel,
      recommendationKind: recommendation.kind,
      lastComfortBand: getAdvancedLevelSpec(gameId, input.level).band,
    },
  };
}
