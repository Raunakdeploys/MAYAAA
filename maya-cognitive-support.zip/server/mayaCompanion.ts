import { invokeLLM } from "./_core/llm";

type CompanionContext = {
  preferredName: string;
  preferredLanguage: string;
  approvedContent: string[];
  message: string;
};

const companionFallback = (name: string) => `I am here with you, ${name}. We can take one small familiar step, repeat an activity instruction, or pause for a moment.`;

export async function createCompanionReply(context: CompanionContext) {
  const approved = context.approvedContent.length ? context.approvedContent.join(", ") : "No additional caregiver-approved details";
  try {
    const response = await invokeLLM({
      model: "gpt-5-mini",
      maxTokens: 180,
      messages: [
        {
          role: "system",
          content: `You are MAYA, a short, warm companion in a cognitive-support app. Reply in 1–3 simple sentences. Use only this caregiver-approved context: name ${context.preferredName}; preferred language ${context.preferredLanguage}; approved familiar content: ${approved}. You can repeat an activity instruction, offer a gentle game hint, suggest a calm pause, or explain the saved session. Never diagnose, assess cognition, discuss decline, claim treatment benefit, invent memories, mention medical emergency steps, or give medication/clinical advice. If asked for health advice, warmly say a caregiver or health professional can help. Avoid scores, penalties, urgency, and jargon.`,
        },
        { role: "user", content: context.message },
      ],
    });
    const content = response.choices[0]?.message.content;
    const text = typeof content === "string" ? content.trim() : "";
    return text || companionFallback(context.preferredName);
  } catch (error) {
    console.warn("[MAYA Companion] generation unavailable", error);
    return companionFallback(context.preferredName);
  }
}

export async function verifyPhotoQuestImage(input: { prompt: string; targetKeywords: string[]; imageDataUrl: string }) {
  try {
    const response = await invokeLLM({
      model: "gemini-3-flash-preview",
      maxTokens: 160,
      outputSchema: {
        name: "photo_quest_verification",
        strict: true,
        schema: {
          type: "object",
          additionalProperties: false,
          properties: {
            verified: { type: "boolean" },
            confidencePercent: { type: "integer", minimum: 0, maximum: 100 },
            response: { type: "string", minLength: 1, maxLength: 160 },
          },
          required: ["verified", "confidencePercent", "response"],
        },
      },
      messages: [
        {
          role: "system",
          content: `You verify one consent-led Photo Quest image. The caregiver-approved prompt is "${input.prompt}" and allowed target words are: ${input.targetKeywords.join(", ")}. Check only whether the requested non-personal object or outdoor place is visibly present. Do not identify people, faces, age, health status, ethnicity, location, or any private attribute. If uncertain, set verified false, confidence below 60, and ask for a gentle retake. A mismatch is never a mistake; use reassuring language.`,
        },
        { role: "user", content: [{ type: "text", text: "Please check this one photo." }, { type: "image_url", image_url: { url: input.imageDataUrl, detail: "low" } }] },
      ],
    });
    const content = response.choices[0]?.message.content;
    const raw = typeof content === "string" ? content : "";
    const parsed = JSON.parse(raw) as { verified?: boolean; confidencePercent?: number; response?: string };
    return {
      verified: Boolean(parsed.verified) && Number(parsed.confidencePercent) >= 60,
      confidencePercent: Math.max(0, Math.min(100, Math.round(Number(parsed.confidencePercent) || 0))),
      response: typeof parsed.response === "string" ? parsed.response.slice(0, 160) : "Let’s take another gentle look.",
    };
  } catch (error) {
    console.warn("[MAYA Photo Quest] verification unavailable", error);
    return { verified: false, confidencePercent: 0, response: "I could not check that photo just now. You can try again whenever you are ready." };
  }
}
