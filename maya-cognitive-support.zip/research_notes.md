# MAYA Playroom Research Notes

## Accessibility and interaction guidance

The [Alzheimer’s Society accessibility guidance](https://www.alzheimers.org.uk/blog/how-design-website-someone-affected-dementia) recommends clear, specific wording; explicit routes back to the start; visible task stages; high contrast; plain backgrounds for text; larger readable type; and avoiding unnecessary jargon. MAYA applies this through large touch controls, one visible task at a time, a persistent Back action, spoken hints, and non-punitive result language.

## Camera implementation reference

The [WebRTC getUserMedia sample](https://webrtc.github.io/samples/src/content/getusermedia/gum/) demonstrates opening an in-browser video stream only after a user action. MAYA Photo Quest will request camera permission only after a direct tap, capture a single still image, and send the image only for the requested challenge verification. By default it will retain the result, not the image itself.

## Implementation boundaries

The system avoids diagnostic claims, face-recognition prompts, automatic camera activation, and score deductions. Memory points represent completed play moments, not health status, treatment response, or a cognitive assessment.
