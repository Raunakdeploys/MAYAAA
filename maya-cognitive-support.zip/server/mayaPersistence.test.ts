import { beforeEach, describe, expect, it, vi } from "vitest";

const mock = vi.hoisted(() => {
  const state: { patient: Record<string, unknown> | null; routine: Record<string, unknown> | null } = {
    patient: null,
    routine: null,
  };

  const tableName = (table: unknown) => (table as Record<symbol, string>)[Symbol.for("drizzle:Name")];
  const rowsFor = (table: unknown) => {
    switch (tableName(table)) {
      case "patients": return state.patient ? [state.patient] : [];
      case "patientRoutines": return state.routine ? [state.routine] : [];
      default: return [];
    }
  };
  const queryFor = (table: unknown) => {
    const query = {
      where: vi.fn(() => query),
      orderBy: vi.fn(() => query),
      limit: vi.fn(async () => rowsFor(table)),
    };
    return query;
  };
  const db = {
    select: vi.fn(() => ({ from: vi.fn((table: unknown) => queryFor(table)) })),
    insert: vi.fn((table: unknown) => ({
      values: vi.fn((values: Record<string, unknown>) => {
        if (tableName(table) === "patients") {
          state.patient = { id: 17, ...values, isArchived: false, createdAt: new Date(), updatedAt: new Date() };
          return { $returningId: async () => [{ id: 17 }] };
        }
        if (tableName(table) === "patientRoutines") {
          state.routine = { id: 31, ...values, createdAt: new Date(), updatedAt: new Date() };
        }
        return {};
      }),
    })),
    update: vi.fn(),
  };

  return { db, state };
});

vi.mock("drizzle-orm/mysql2", () => ({ drizzle: () => mock.db }));

import { getMayaOverview, saveMayaProfile } from "./db";

describe("MAYA profile persistence cycle", () => {
  beforeEach(() => {
    mock.state.patient = null;
    mock.state.routine = null;
    process.env.DATABASE_URL = "mock://maya-persistence-test";
  });

  it("writes a caregiver-approved profile and returns it through a fresh overview read", async () => {
    const saved = await saveMayaProfile(9, {
      preferredName: "Aita",
      preferredLanguage: "Assamese",
      morningRoutine: "Wake up · drink water · take medicine · eat breakfast",
      medicineLocation: "Red box beside the window",
      approvedContent: ["Steel water glass", "Tea cup", "Rina’s voice"],
    });

    const refreshed = await getMayaOverview(9);

    expect(saved.patient?.preferredName).toBe("Aita");
    expect(saved.routine?.approvedContent).toEqual(["Steel water glass", "Tea cup", "Rina’s voice"]);
    expect(refreshed.patient?.preferredLanguage).toBe("Assamese");
    expect(refreshed.routine?.medicineLocation).toBe("Red box beside the window");
  });
});
