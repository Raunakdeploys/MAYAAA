import { describe, expect, it } from "vitest";
import { mayaActivityInput, mayaCameraVerifyInput, mayaProfileInput } from "./mayaSchemas";

describe("MAYA persistence input safeguards", () => {
  it("accepts a complete caregiver-approved routine", () => {
    const result = mayaProfileInput.safeParse({
      preferredName: "Aita",
      preferredLanguage: "Assamese",
      morningRoutine: "Wake up · drink water · take medicine · eat breakfast",
      medicineLocation: "Red box beside the window",
      approvedContent: ["Steel water glass", "Tea cup", "Rina’s voice"],
    });

    expect(result.success).toBe(true);
  });

  it("rejects incomplete personal routine content", () => {
    const result = mayaProfileInput.safeParse({
      preferredName: "",
      preferredLanguage: "Assamese",
      morningRoutine: "",
      medicineLocation: "",
      approvedContent: [],
    });

    expect(result.success).toBe(false);
  });

  it("keeps activity accuracy within a valid percentage range", () => {
    const result = mayaActivityInput.safeParse({
      patientId: 1,
      gameId: "mission_home",
      templateId: "morning_routine",
      level: 2,
      language: "Assamese",
      completed: true,
      accuracyPercent: 140,
      hintsUsed: 1,
      responseTimeSeconds: 42,
      frustrationFlag: false,
      mood: "calm",
      syncStatus: "synced",
    });

    expect(result.success).toBe(false);
  });

  it("accepts only a bounded captured image data URL for Photo Quest verification", () => {
    expect(mayaCameraVerifyInput.safeParse({ challengeId: 1, imageDataUrl: "data:image/jpeg;base64,aGVsbG8=" }).success).toBe(true);
    expect(mayaCameraVerifyInput.safeParse({ challengeId: 1, imageDataUrl: "https://untrusted.example/image.jpg" }).success).toBe(false);
  });
});
