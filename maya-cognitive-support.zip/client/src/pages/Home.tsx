/**
 * MAYA / Home Rituals: the working prototype keeps patient actions calm, generous,
 * and familiar, while the caregiver experience gives supportive context, never rankings.
 */
import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import MayaPlayroom from "@/components/MayaPlayroom";
import MayaCompanion from "@/components/MayaCompanion";
import PhotoQuest from "@/components/PhotoQuest";
import { ADVANCED_GAME_CATALOG } from "@shared/advancedGames";
import { toast } from "sonner";
import {
  Activity, ArrowLeft, ArrowRight, Bell, BookOpen, CalendarDays, Camera, Check,
  CheckCircle2, ChevronRight, CircleHelp, Clock3, CloudOff, Coffee, Compass,
  HeartHandshake, Home as HomeIcon, Info, Leaf, LoaderCircle, LockKeyhole, MessageCircle,
  Mic, Play, Plus, Radio, Send, Settings2, ShieldCheck, Sparkles, Speaker, Sun,
  UserRound, UsersRound, Volume2, WandSparkles, Waves, XCircle
} from "lucide-react";

const LOGO = "/manus-storage/maya-logo_253ccd3e.png";
const MISSION_HOME = "/manus-storage/maya-mission-home_590d5ad4.jpg";
const MEMORY_VILLAGE = "/manus-storage/maya-memory-village_63d60acf.jpg";
const CARE_VOICE = "/manus-storage/maya-caregiver-voice_41c74f7b.jpg";

type Mode = "patient" | "caregiver";
type PatientScreen = "home" | "today" | "games" | "mission" | "feedback-good" | "feedback-support" | "complete" | "talk" | "help" | "companion" | "photoquest";
type CareScreen = "dashboard" | "onboard" | "demo";
type StoredPatient = { id: number; preferredName: string; preferredLanguage: string } | null;
type StoredRoutine = { morningRoutine: string; medicineLocation: string; approvedContent: string[] } | null;
type StoredActivity = { id: number; completed: boolean; frustrationFlag: boolean };
type StoredNote = { id: number; body: string; reviewed: boolean };
type PlayroomGame = { id: string; name: string; progress: { unlockedLevel: number; highestLevel: number; memoryPoints: number; totalSessions: number; completedSessions: number } };
type StoredGameSession = { id: number; gameId: string; level: number; pointsEarned: number; occurredAt: Date };
type StoredPhotoQuest = { id: number; prompt: string; status: "pending" | "verified" | "needs_retake" | "declined"; awardedPoints: number; confidencePercent: number; createdAt?: Date };
type StoredDomainEngagement = { domain: "visual_association" | "working_memory" | "routine_planning" | "selective_attention" | "language_reminiscence" | "spatial_orientation"; momentsCompleted: number; momentsWithSupport: number; totalParticipationPoints: number; lastEngagedAt?: Date | null };
type StoredAdaptiveRecommendation = { id: number; gameId: string; kind: "advance" | "repeat_with_new_content" | "bridge_assessment" | "gentler_choice"; currentLevel: number; recommendedLevel: number; lowerLevel?: number | null; upperLevel?: number | null; reason: string; status: "available" | "started" | "completed" | "dismissed" };
type ProfileDraft = { patientId?: number; preferredName: string; preferredLanguage: string; morningRoutine: string; medicineLocation: string; approvedContent: string[] };

function speak(text: string) {
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
    const speech = new SpeechSynthesisUtterance(text);
    speech.rate = 0.9;
    speech.pitch = 1;
    window.speechSynthesis.speak(speech);
  }
}

function MayaBrand({ light = false }: { light?: boolean }) {
  return <div className="maya-brand"><img src={LOGO} alt="MAYA home-and-path mark" /><span style={{ color: light ? "white" : undefined }}>MAYA</span></div>;
}

function SavedDataState({ loading, error, onRetry }: { loading?: boolean; error?: string | null; onRetry?: () => void }) {
  return <section className="data-state" role={error ? "alert" : "status"}><div><span className="state-icon">{loading ? <LoaderCircle size={27} className="animate-spin" /> : <CloudOff size={27} />}</span><h2>{loading ? "Opening your saved Maya world…" : "Your saved Maya world is unavailable right now."}</h2><p>{loading ? "We are checking the private caregiver profile and approved routine." : "Nothing has been lost. Please try again before making changes."}</p>{error && <p style={{ fontSize: 12 }}>Connection detail: {error}</p>}{!loading && <button onClick={onRetry}>Try again <ArrowRight size={16} /></button>}</div></section>;
}

function ViewSwitch({ mode, setMode }: { mode: Mode; setMode: (mode: Mode) => void }) {
  return <div className="view-switch" aria-label="Prototype view selector">
    <button className={mode === "patient" ? "active" : ""} onClick={() => setMode("patient")}>AITA’S TABLET</button>
    <button className={mode === "caregiver" ? "active" : ""} onClick={() => setMode("caregiver")}>CAREGIVER VIEW</button>
  </div>;
}

function PatientShell({ children, screen, setScreen, name, pending }: { children: React.ReactNode; screen: PatientScreen; setScreen: (screen: PatientScreen) => void; name: string; pending: number }) {
  const greeting = `Good morning, ${name}. You have two small activities today.`;
  return <main className="patient-stage">
    <section className="tablet-shell" aria-label="MAYA patient tablet preview">
      <header className="patient-topbar">
        <MayaBrand />
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div className="patient-status"><i className="status-dot" /> Saved safely</div>
          <button className="voice-orb" aria-label="Listen to this screen" onClick={() => speak(greeting)}><Volume2 size={22} /></button>
        </div>
      </header>
      <div className="bamboo-line" />
      {children}
      {screen !== "home" && <button className="soft-back" style={{ position: "absolute", zIndex: 6, left: 58, bottom: 22 }} onClick={() => setScreen("home")}><ArrowLeft size={16} /> Back to home</button>}
      {pending > 0 && screen !== "complete" && <div style={{ position: "absolute", zIndex: 5, right: 30, bottom: 20, display: "flex", alignItems: "center", gap: 7, color: "#6b6a64", fontSize: 11, fontWeight: 800 }}><CloudOff size={15} /> {pending} {pending === 1 ? "activity" : "activities"} saved here</div>}
    </section>
  </main>;
}

function PatientHome({ name, ready, setScreen, openSetup, openPlayroom }: { name: string; ready: boolean; setScreen: (screen: PatientScreen) => void; openSetup: () => void; openPlayroom: () => void }) {
  return <div className="patient-view home-composition">
    <section>
      <p className="eyebrow">Wednesday, 26 August</p>
      <h1 className="patient-title">Good morning, {name}.</h1>
      <p className="patient-subtitle">{ready ? <>We can take one familiar step together. You have <strong>2 small activities</strong> today.</> : <>You can explore six gentle games now, or let a caregiver prepare a familiar routine first.</>}</p>
      <div className="home-actions">
        <button className="action-button primary" onClick={() => ready ? setScreen("games") : openPlayroom()}><span className="icon-box"><Play size={21} fill="currentColor" /></span><span>{ready ? "Begin a familiar step" : "Explore the Playroom"}<small>{ready ? "A gentle 3-minute moment together" : "Six playable games, ready now"}</small></span><ChevronRight style={{ marginLeft: "auto" }} /></button>
        <div className="ritual-path">
          <button className="action-button" onClick={() => ready ? setScreen("today") : openSetup()}><span className="icon-box"><Sun size={19} /></span><span>See today’s plan<small>Your small reminders</small></span><ChevronRight /></button>
          <button className="action-button" onClick={() => ready ? setScreen("photoquest") : openSetup()}><span className="icon-box"><Camera size={19} /></span><span>Try Photo Quest<small>Find a familiar thing</small></span><ChevronRight /></button>
          <button className="action-button" onClick={() => ready ? setScreen("companion") : openSetup()}><span className="icon-box"><MessageCircle size={19} /></span><span>Ask MAYA<small>Speak or type a question</small></span><ChevronRight /></button>
        </div>
      </div>
    </section>
    <aside className="home-illustration" aria-label="A familiar morning room">
      <img src={MISSION_HOME} alt="A warm home scene with familiar morning objects" />
      <span className="day-token">A familiar morning</span>
      <p className="illustration-quote">“Let’s begin with a familiar step.”</p>
    </aside>
  </div>;
}

function TodayView({ setScreen }: { setScreen: (screen: PatientScreen) => void }) {
  const cards = [
    { icon: <BookOpen size={23} />, label: "Medicine", text: "Medicine after breakfast", done: true },
    { icon: <Waves size={23} />, label: "Water", text: "Drink one glass of water", done: true },
    { icon: <Play size={23} />, label: "Activity", text: "Play a 3-minute memory", action: () => setScreen("games") },
    { icon: <CalendarDays size={23} />, label: "Appointment", text: "Clinic visit on Friday" },
  ];
  return <div className="patient-view">
    <button className="soft-back" onClick={() => setScreen("home")}><ArrowLeft size={16} /> Back</button>
    <div className="page-heading"><div><p className="eyebrow">Your gentle plan</p><h1 className="patient-title">Today’s small steps.</h1><p className="patient-subtitle">There is no rush. You can come back whenever you like.</p></div></div>
    <div className="today-grid">
      {cards.map((card) => <button className={`today-card ${card.done ? "done" : ""}`} key={card.label} onClick={card.action ?? (() => speak(`${card.label}. ${card.text}`))}>
        <span className="card-icon">{card.icon}</span><h3>{card.label}</h3><p>{card.text}</p>{card.done ? <span className="tiny-done"><CheckCircle2 size={15} /> Done for now</span> : <span className="tiny-done" style={{ color: "#27326b" }}>Listen <Volume2 size={14} /></span>}
      </button>)}
    </div>
  </div>;
}

function GamesView({ setScreen }: { setScreen: (screen: PatientScreen) => void }) {
  return <div className="patient-view"><MayaPlayroom onBack={() => setScreen("home")} /></div>;
}

function MissionView({ setScreen, setHint }: { setScreen: (screen: PatientScreen) => void; setHint: (value: boolean) => void }) {
  const answer = (correct: boolean) => { if (correct) setScreen("feedback-good"); else setScreen("feedback-support"); };
  return <div className="patient-view">
    <button className="soft-back" onClick={() => setScreen("games")}><ArrowLeft size={16} /> Choose another activity</button>
    <div className="mission-layout">
      <article className="mission-scene"><img src={MISSION_HOME} alt="Morning room with a red medicine box beside the window" /><div className="scene-shade" /><span className="scene-caption">Your familiar morning room</span></article>
      <article className="mission-card">
        <div className="voice-row"><button onClick={() => speak("Let’s do this together. What comes after drinking water?")}><Volume2 size={17} /></button> Listen again</div>
        <p className="eyebrow">Morning mission · familiar steps</p>
        <h1 className="mission-question">What comes after drinking water?</h1>
        <div className="choice-grid">
          <button className="choice-card" onClick={() => answer(true)}><BookOpen size={25} />Medicine</button>
          <button className="choice-card" onClick={() => answer(false)}><Coffee size={25} />Tea</button>
          <button className="choice-card" onClick={() => answer(false)}><Clock3 size={25} />Rest</button>
        </div>
        <div className="hint-strip"><Sparkles size={18} /><span><strong>Need a little help?</strong> The red box is beside the window.</span></div>
        <button className="soft-back" style={{ marginTop: 14, marginBottom: 0 }} onClick={() => { setHint(true); speak("The red medicine box is beside the window."); }}>Hear the hint again <Volume2 size={15} /></button>
      </article>
    </div>
  </div>;
}

function FeedbackView({ good, setScreen, saveActivity, saving }: { good: boolean; setScreen: (screen: PatientScreen) => void; saveActivity: () => Promise<void>; saving: boolean }) {
  return <div className="patient-view feedback-wrap"><article className={`feedback-card ${good ? "" : "support"}`}>
    <div className="feedback-icon">{good ? <Check size={43} strokeWidth={2.5} /> : <HeartHandshake size={43} strokeWidth={2.2} />}</div>
    <h2>{good ? "Yes, that is right. Well remembered." : "That is okay. Let us look together."}</h2>
    <p>{good ? "You found the step that comes after drinking water. We can keep going slowly." : "The medicine comes next. The red box is beside the window. You can try with a little help."}</p>
    {good ? <div className="feedback-actions"><button className="support-button" onClick={() => setScreen("games")}>Rest for now</button><button className="support-button primary" disabled={saving} onClick={() => void saveActivity()}>{saving ? "Saving safely…" : "Save this step"} <ArrowRight size={17} /></button></div> : <div className="feedback-actions"><button className="support-button" onClick={() => setScreen("home")}>Rest</button><button className="support-button primary" onClick={() => setScreen("mission")}>Try together <ArrowRight size={17} /></button></div>}
  </article></div>;
}

function CompletionView({ setScreen, pending }: { setScreen: (screen: PatientScreen) => void; pending: number }) {
  return <div className="patient-view feedback-wrap"><article className="completion-card"><p className="eyebrow">A quiet moment, saved</p><h2>You spent time with Maya today.</h2><div className="completed-list"><div><CheckCircle2 size={20} /> Morning routine</div><div><CheckCircle2 size={20} /> Water reminder</div></div><p className="complete-note"><CheckCircle2 size={16} /> {pending} activity {pending === 1 ? "record is" : "records are"} saved safely for your caregiver.</p><button className="support-button primary" onClick={() => setScreen("talk")}><Send size={16} /> Send a message</button><button className="support-button" onClick={() => setScreen("home")}>Rest now</button></article></div>;
}

function TalkView({ setScreen }: { setScreen: (screen: PatientScreen) => void }) {
  return <div className="patient-view"><button className="soft-back" onClick={() => setScreen("home")}><ArrowLeft size={16} /> Back</button><div className="talk-layout"><article className="talk-panel"><p className="eyebrow">Family radio</p><h1 className="patient-title">A message from Rina.</h1><div className="wave" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /></div><div className="care-message"><Volume2 size={18} /> “Good morning, Aita. I will visit after lunch.”</div><img src={CARE_VOICE} alt="A warm family voice-message moment" /></article><aside className="help-panel"><p className="eyebrow">Your reply</p><h2 style={{ margin: 0, color: "#17224e", fontFamily: "Fraunces, serif", fontSize: 29, lineHeight: 1.12 }}>Would you like to send a voice postcard?</h2><p style={{ margin: "15px 0 23px", color: "#6b6a64", fontSize: 14, lineHeight: 1.58 }}>Your family will hear it when the device is connected.</p><button className="support-button primary" style={{ width: "100%" }} onClick={() => toast.success("Your voice postcard is ready to record.")}><Mic size={18} /> Record a message</button><button className="soft-back" style={{ marginTop: 17, marginBottom: 0 }} onClick={() => { speak("Good morning, Rina. I am thinking of you."); toast.message("A gentle example message is playing."); }}>Hear an example <Volume2 size={15} /></button></aside></div></div>;
}

function HelpView({ setScreen }: { setScreen: (screen: PatientScreen) => void }) {
  return <div className="patient-view feedback-wrap"><article className="feedback-card support"><div className="feedback-icon"><HeartHandshake size={43} /></div><h2>Would you like to rest?</h2><p>It is alright to pause. Your activities are saved safely, and you can return whenever you feel ready.</p><div className="feedback-actions"><button className="support-button" onClick={() => setScreen("talk")}>Hear a family message</button><button className="support-button primary" onClick={() => setScreen("home")}>Rest now</button></div></article></div>;
}

function CaregiverDashboard({ name, routine, activityCount, recentActivities, supportNotes, games, gameSessions, photoChallenges, totalMemoryPoints, photoQuestMemoryPoints, domainEngagement, adaptiveRecommendations, preview, noteSaving, onCreateNote, onReviewNote }: { name: string; routine: StoredRoutine; activityCount: number; recentActivities: StoredActivity[]; supportNotes: StoredNote[]; games: PlayroomGame[]; gameSessions: StoredGameSession[]; photoChallenges: StoredPhotoQuest[]; totalMemoryPoints: number; photoQuestMemoryPoints: number; domainEngagement: StoredDomainEngagement[]; adaptiveRecommendations: StoredAdaptiveRecommendation[]; preview?: boolean; noteSaving: boolean; onCreateNote: () => Promise<void>; onReviewNote: (noteId: number) => Promise<void> }) {
  const [range, setRange] = useState("7 DAYS");
  const careNote = supportNotes.find(note => !note.reviewed);
  const hasRepeatedFrustration = recentActivities.filter(activity => activity.frustrationFlag).length >= 3;
  const activeGames = games.filter(game => game.progress.totalSessions > 0);
  const latestQuest = photoChallenges[0];
  const availableBridge = adaptiveRecommendations.find(item => item.kind === "bridge_assessment" && item.status === "available");
  const domainNames: Record<StoredDomainEngagement["domain"], string> = { visual_association: "Familiar pieces", working_memory: "Lantern trails", routine_planning: "Daily stories", selective_attention: "Market moments", language_reminiscence: "Story garden", spatial_orientation: "Village visits" };
  const currentExplanation = activityCount === 0 ? "No activity recorded yet. The person may be resting, or their routine may not have begun." : range === "1 DAY" ? "Today’s engagement is saved and ready for a caregiver review." : range === "30 DAYS" ? "This view will compare engagement only with this person’s own history." : "This view will show an individual engagement pattern as activity is recorded.";
  return <>
    <header className="care-header"><div><h1>{name}’s day</h1><p>{preview ? "Presentation preview only — no personal record has been created." : "Engagement and routine support — not a clinical score."}</p></div><div className="patient-chip"><span className="patient-avatar">{preview ? "P" : "A"}</span> {preview ? "Preview" : "Assamese · Offline first"}</div></header>
    <div className="care-grid">
      <section className="care-card compass-card"><div className="section-heading"><div><h2>Support compass</h2><p>Compared only with {name}’s own baseline.</p></div><div className="range-tabs">{["1 DAY", "7 DAYS", "30 DAYS"].map((item) => <button key={item} className={range === item ? "active" : ""} onClick={() => setRange(item)}>{item}</button>)}</div></div><div className="compass-read"><div className="balance-line" /><div className="compass-needle" /></div><div className="compass-explainer"><Leaf size={19} /><span>{currentExplanation}</span></div></section>
      <section className="care-card routine-card"><div className="section-heading"><div><h2>Approved routine</h2><p>Saved by this caregiver.</p></div><Sun size={22} color="#d8aa3d" /></div><div className="routine-count"><strong>{activityCount}</strong><span>{activityCount === 1 ? "activity record" : "activity records"}</span></div><div className="completion-bar"><i style={{ width: `${Math.min(100, activityCount * 20)}%` }} /></div><div className="routine-items"><div className="routine-item"><CheckCircle2 size={16} /> {routine?.morningRoutine || "No routine saved yet"}</div><div className="routine-item"><CheckCircle2 size={16} /> Medicine: {routine?.medicineLocation || "Not recorded"}</div></div></section>
      <section className="care-card engagement-card"><div className="engagement-top"><div><h2 style={{ margin: 0, color: "#17224e", fontFamily: "Fraunces, serif", fontSize: 25 }}>Engagement</h2><p style={{ margin: "5px 0 0", color: "#6b6a64", fontSize: 12 }}>Stored activity records</p></div><span className="steady-pill"><i /> {activityCount ? "Recorded" : "Waiting"}</span></div><div className="spark"><i style={{ height: `${Math.max(15, Math.min(90, activityCount * 18))}%` }} /><i /><i /><i /><i /><i /><i /></div><div className="spark-labels"><span>Individual history</span><span>Saved safely</span></div></section>
      <section className="care-card alert-card"><span className="alert-kicker"><Info size={14} /> {careNote || hasRepeatedFrustration ? "Care context" : "No check-in suggested"}</span><div className="section-heading" style={{ marginTop: 8 }}><div><h2>{careNote ? "A caregiver note is waiting." : hasRepeatedFrustration ? "Several activities needed more support." : "No review is needed right now."}</h2></div></div><p>{careNote ? careNote.body : hasRepeatedFrustration ? "This is not a diagnosis. Consider checking in to see whether the person is tired, unwell, or needs more support." : "MAYA will not infer a concern from missing data or a single difficult moment."}</p><div className="why-list"><div><Activity size={15} /> Notes and activity history remain connected only to {name}’s caregiver account.</div><div><LockKeyhole size={15} /> No comparative score or diagnostic label is stored.</div></div><div className="alert-actions">{careNote ? <button className="primary" disabled={noteSaving} onClick={() => void onReviewNote(careNote.id)}>{noteSaving ? "Saving…" : "Mark reviewed"}</button> : <button className="primary" disabled={noteSaving} onClick={() => void onCreateNote()}>{noteSaving ? "Saving…" : "Record a check-in"}</button>}<button onClick={() => toast.message("Use the caregiver’s preferred contact method to check in.")}>Contact family</button></div></section>
      <section className="care-card voice-card"><h2>Send a familiar voice.</h2><p>Rina’s messages are available to play in Family Radio. A personal voice can make a reminder feel more reassuring.</p><button onClick={() => toast.success("Voice message composer opened.")}><Mic size={16} /> Send voice message</button></section>
      <section className="care-card" style={{ padding: 27 }}><div className="section-heading"><div><h2>Playroom journeys</h2><p>{activeGames.length ? `${activeGames.length} game${activeGames.length === 1 ? "" : "s"} have saved moments.` : "No Playroom session saved yet."}</p></div><Sparkles size={21} color="#d8aa3d" /></div><div className="routine-count"><strong>{totalMemoryPoints}</strong><span>participation points from completed moments</span></div><div className="game-progress-list">{games.map(game => { const title = ADVANCED_GAME_CATALOG.find(item => item.id === game.id)?.name ?? game.name; return <div className="game-progress-row" key={game.id}><div><strong>{title}</strong><span>Level {game.progress.unlockedLevel} ready · {game.progress.completedSessions} moments</span></div><i><b style={{ width: `${Math.min(100, game.progress.highestLevel * 5)}%` }} /></i></div>; })}</div></section>
      <section className="care-card domain-card"><div className="section-heading"><div><h2>Favourite activity worlds</h2><p>Saved participation and requested support—never a health score.</p></div><Leaf size={21} color="#347c78" /></div>{domainEngagement.length ? <div className="domain-list">{domainEngagement.map(item => <div className="domain-row" key={item.domain}><div><strong>{domainNames[item.domain]}</strong><small>{item.momentsCompleted} {item.momentsCompleted === 1 ? "moment" : "moments"} completed · {item.momentsWithSupport} with support</small></div><span>{item.totalParticipationPoints} points</span></div>)}</div> : <div className="empty-care-state"><Leaf size={18} /> Favourite activity worlds will appear after a saved Playroom moment.</div>}</section>
      <section className="care-card adaptive-card"><div className="section-heading"><div><h2>Comfortable next step</h2><p>Adaptive support is based on this person’s recent game interaction only.</p></div><HeartHandshake size={21} color="#347c78" /></div>{availableBridge ? <div className="adaptive-available"><span>Supported practice</span><h3>{ADVANCED_GAME_CATALOG.find(item => item.id === availableBridge.gameId)?.name ?? "Playroom"} between levels {availableBridge.lowerLevel} and {availableBridge.upperLevel}</h3><p>{availableBridge.reason}</p></div> : <div className="adaptive-available quiet"><span>No supported bridge waiting</span><p>MAYA will offer a gentler practice moment only after repeated difficulty near a level boundary. It does not calculate a cognitive score.</p></div>}</section>
      <section className="care-card session-history-card"><div className="section-heading"><div><h2>Recent play moments</h2><p>Saved engagement, shown without ratings or comparisons.</p></div><Activity size={21} color="#347c78" /></div>{gameSessions.length ? <div className="session-history-list">{gameSessions.slice(0, 5).map(session => { const game = games.find(item => item.id === session.gameId); const date = session.occurredAt ? new Date(session.occurredAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "Saved today"; return <div className="session-history-row" key={session.id}><span className="session-dot" /><div><strong>{game?.name ?? "Playroom activity"} · Level {session.level}</strong><small>{date} · {session.pointsEarned ? `+${session.pointsEarned} memory points` : "Moment saved"}</small></div></div>; })}</div> : <div className="empty-care-state"><Activity size={18} /> The first completed game will appear here.</div>}</section>
      <section className="care-card photo-care-card"><div className="section-heading"><div><h2>Photo Quest</h2><p>One consent-led camera activity at a time.</p></div><Camera size={21} color="#347c78" /></div>{latestQuest ? <><strong className="photo-care-title">{latestQuest.prompt}</strong><p>{latestQuest.status === "verified" ? `Verified with ${latestQuest.confidencePercent}% confidence. The photo itself was not retained.` : latestQuest.status === "needs_retake" ? "A gentle retake was offered. No points were removed." : "The prepared quest is waiting for a patient choice."}</p><div className="photo-care-score"><span>{latestQuest.awardedPoints ? `+${latestQuest.awardedPoints} points` : "No point change"}</span><small>{photoQuestMemoryPoints} Photo Quest points total</small></div></> : <div className="empty-care-state"><Camera size={18} /> No Photo Quest recorded yet.</div>}</section>
      <section className="care-card photo-history-card"><div className="section-heading"><div><h2>Photo Quest history</h2><p>Verification results only; captured photos are not retained.</p></div><ShieldCheck size={21} color="#347c78" /></div>{photoChallenges.length ? <div className="quest-history-list">{photoChallenges.slice(0, 5).map(challenge => <div className="quest-history-row" key={challenge.id}><div><strong>{challenge.prompt}</strong><small>{challenge.status === "verified" ? `Verified · ${challenge.confidencePercent}% confidence` : challenge.status === "needs_retake" ? "Retake offered" : "Waiting for a choice"}</small></div><span className={challenge.awardedPoints ? "earned" : "quiet"}>{challenge.awardedPoints ? `+${challenge.awardedPoints}` : "—"}</span></div>)}</div> : <div className="empty-care-state"><ShieldCheck size={18} /> Results will appear after a Photo Quest.</div>}</section>
      <section className="care-card demo-story-card"><p className="eyebrow">Hackathon demo path</p><h2>Show one connected story, not a dashboard.</h2><ol><li>Caregiver approves a familiar routine.</li><li>Patient completes one game or Photo Quest.</li><li>Points and levels are saved privately.</li><li>Caregiver sees engagement context—not a diagnosis.</li></ol></section>
      <section className="care-card" style={{ padding: 27 }}><div className="section-heading"><div><h2>Persistent activity log</h2><p>Activity stays private to this caregiver account.</p></div><LockKeyhole size={21} color="#347c78" /></div><div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, padding: "15px", borderRadius: 14, background: "#eef5ef" }}><div><strong style={{ display: "block", color: "#17224e", fontSize: 15 }}>{activityCount} {activityCount === 1 ? "activity saved" : "activities saved"}</strong><span style={{ display: "block", marginTop: 3, color: "#627164", fontSize: 12 }}>New activity appears here after the patient completes a session</span></div><CheckCircle2 size={20} color="#347c78" /></div></section>
    </div>
  </>;
}

function Onboarding({ patient, routine, isAuthenticated, saving, onSaveProfile, setCareScreen }: { patient: StoredPatient; routine: StoredRoutine; isAuthenticated: boolean; saving: boolean; onSaveProfile: (input: ProfileDraft) => Promise<void>; setCareScreen: (screen: CareScreen) => void }) {
  const [draft, setDraft] = useState(patient?.preferredName ?? "");
  const [language, setLanguage] = useState(patient?.preferredLanguage ?? "");
  const [morningRoutine, setMorningRoutine] = useState(routine?.morningRoutine ?? "");
  const [medicineLocation, setMedicineLocation] = useState(routine?.medicineLocation ?? "");
  const [approvedContent, setApprovedContent] = useState(routine?.approvedContent.join("\n") ?? "");
  useEffect(() => { if (patient) setDraft(patient.preferredName); if (patient) setLanguage(patient.preferredLanguage); if (routine) { setMorningRoutine(routine.morningRoutine); setMedicineLocation(routine.medicineLocation); setApprovedContent(routine.approvedContent.join("\n")); } }, [patient, routine]);
  const submit = async (event: React.FormEvent) => { event.preventDefault(); if (!isAuthenticated) { startLogin(); return; } try { await onSaveProfile({ patientId: patient?.id, preferredName: draft, preferredLanguage: language, morningRoutine, medicineLocation, approvedContent: approvedContent.split("\n").map(item => item.trim()).filter(Boolean) }); setCareScreen("dashboard"); } catch { toast.error("Please complete each caregiver-approved field before saving."); } };
  return <div className="onboard-wrap"><header className="care-header"><div><h1>Build a familiar world</h1><p>Everything Maya uses is chosen and approved by the caregiver.</p></div></header><section className="onboard-hero"><div className="onboard-copy"><p className="eyebrow" style={{ color: "#d8aa3d" }}>Caregiver setup</p><h2>Turn a daily routine into a gentle game.</h2><p>Maya selects from the personal objects, people, places, and language you approve. It does not invent cultural facts or unverified memories.</p></div><img src={MEMORY_VILLAGE} alt="A peaceful memory village with home, market, clinic, and banyan tree" /></section><form className="onboard-form" onSubmit={(event) => void submit(event)}><section className="form-section"><h3>Who is playing?</h3><label htmlFor="preferred-name">Preferred name</label><input id="preferred-name" placeholder="Enter their preferred name" value={draft} onChange={(event) => setDraft(event.target.value)} /><label htmlFor="language">Preferred language</label><input id="language" placeholder="For example, Assamese" value={language} onChange={(event) => setLanguage(event.target.value)} /></section><section className="form-section"><h3>Morning routine</h3><label htmlFor="routine">Approved order</label><textarea id="routine" placeholder="For example: Wake up · drink water · take medicine" value={morningRoutine} onChange={(event) => setMorningRoutine(event.target.value)} /><label htmlFor="medicine">Medicine location</label><input id="medicine" placeholder="Describe the approved location" value={medicineLocation} onChange={(event) => setMedicineLocation(event.target.value)} /></section><section className="form-section span-two"><h3>Approved memories and voices</h3><label htmlFor="approved-content">One caregiver-approved person, object, or place per line</label><textarea id="approved-content" placeholder="For example: a familiar water glass" value={approvedContent} onChange={(event) => setApprovedContent(event.target.value)} /></section><div className="form-save"><p><strong style={{ color: "#17224e" }}>Safety check:</strong> Maya will use only this caregiver-approved library, remove ambiguous prompts, and never show a timer.</p><button type="submit" disabled={saving}>{saving ? "Saving safely…" : isAuthenticated ? "Save routine & build game" : "Sign in to save securely"} <WandSparkles size={16} /></button></div></form></div>;
}

function CaregiverApp({ patient, routine, isAuthenticated, loading, error, activityCount, recentActivities, supportNotes, games, gameSessions, photoChallenges, totalMemoryPoints, photoQuestMemoryPoints, domainEngagement, adaptiveRecommendations, saving, noteSaving, onSaveProfile, onCreateNote, onReviewNote, retry }: { patient: StoredPatient; routine: StoredRoutine; isAuthenticated: boolean; loading: boolean; error: string | null; activityCount: number; recentActivities: StoredActivity[]; supportNotes: StoredNote[]; games: PlayroomGame[]; gameSessions: StoredGameSession[]; photoChallenges: StoredPhotoQuest[]; totalMemoryPoints: number; photoQuestMemoryPoints: number; domainEngagement: StoredDomainEngagement[]; adaptiveRecommendations: StoredAdaptiveRecommendation[]; saving: boolean; noteSaving: boolean; onSaveProfile: (input: ProfileDraft) => Promise<void>; onCreateNote: () => Promise<void>; onReviewNote: (noteId: number) => Promise<void>; retry: () => void }) {
  const [careScreen, setCareScreen] = useState<CareScreen>(() => typeof window !== "undefined" && new URLSearchParams(window.location.search).get("preview") === "caregiver" ? "demo" : "dashboard");
  const isPreview = careScreen === "demo";
  const name = isPreview ? "Demo participant" : patient?.preferredName ?? "your family member";
  const showSetup = (!patient && !isPreview) || careScreen === "onboard";
  const previewGames: PlayroomGame[] = [
    { id: "pairing_table", name: "Pairing Table", progress: { unlockedLevel: 4, highestLevel: 3, memoryPoints: 48, totalSessions: 3, completedSessions: 3 } },
    { id: "lantern_path", name: "Lantern Path", progress: { unlockedLevel: 3, highestLevel: 2, memoryPoints: 34, totalSessions: 2, completedSessions: 2 } },
    { id: "daily_order", name: "Daily Order", progress: { unlockedLevel: 2, highestLevel: 1, memoryPoints: 20, totalSessions: 1, completedSessions: 1 } },
    { id: "market_basket", name: "Market Basket", progress: { unlockedLevel: 1, highestLevel: 1, memoryPoints: 0, totalSessions: 0, completedSessions: 0 } },
    { id: "word_garden", name: "Word Garden", progress: { unlockedLevel: 1, highestLevel: 1, memoryPoints: 0, totalSessions: 0, completedSessions: 0 } },
    { id: "village_map", name: "Village Map", progress: { unlockedLevel: 1, highestLevel: 1, memoryPoints: 0, totalSessions: 0, completedSessions: 0 } },
  ];
  const previewSessions: StoredGameSession[] = [{ id: -1, gameId: "pairing_table", level: 3, pointsEarned: 20, occurredAt: new Date() }, { id: -2, gameId: "lantern_path", level: 2, pointsEarned: 17, occurredAt: new Date() }, { id: -3, gameId: "daily_order", level: 1, pointsEarned: 20, occurredAt: new Date() }];
  const previewQuests: StoredPhotoQuest[] = [{ id: -4, prompt: "Find a mango tree", status: "verified", confidencePercent: 88, awardedPoints: 12 }, { id: -5, prompt: "Find a familiar water glass", status: "needs_retake", confidencePercent: 42, awardedPoints: 0 }];
  const previewDomains: StoredDomainEngagement[] = [{ domain: "visual_association", momentsCompleted: 3, momentsWithSupport: 1, totalParticipationPoints: 48 }, { domain: "working_memory", momentsCompleted: 2, momentsWithSupport: 1, totalParticipationPoints: 34 }, { domain: "routine_planning", momentsCompleted: 1, momentsWithSupport: 0, totalParticipationPoints: 20 }];
  const previewRecommendations: StoredAdaptiveRecommendation[] = [{ id: -8, gameId: "lantern_path", kind: "bridge_assessment", currentLevel: 3, recommendedLevel: 2, lowerLevel: 2, upperLevel: 3, reason: "Let us try a gentler bridge between two nearby challenges.", status: "available" }];
  const visibleGames = isPreview ? previewGames : games; const visibleSessions = isPreview ? previewSessions : gameSessions; const visibleQuests = isPreview ? previewQuests : photoChallenges; const visibleRoutine = isPreview ? { morningRoutine: "Drink water · breakfast · gentle Playroom", medicineLocation: "Approved home location", approvedContent: [] } : routine;
  return <main className="caregiver-stage"><div className="caregiver-layout"><aside className="care-sidebar"><MayaBrand light /><p className="care-label">Care space</p><nav className="care-nav"><button className={!showSetup && !isPreview ? "active" : ""} onClick={() => setCareScreen("dashboard")}><Compass size={18} /><span>Today’s support</span></button><button className={showSetup ? "active" : ""} onClick={() => setCareScreen("onboard")}><Settings2 size={18} /><span>Personalize Maya</span></button><button className={isPreview ? "active" : ""} onClick={() => setCareScreen("demo")}><Sparkles size={18} /><span>Presentation preview</span></button><button onClick={() => toast.message("Family circle is ready for additional caregivers in the full product.")}><UsersRound size={18} /><span>Family circle</span></button></nav><div className="care-sidebar-footer"><span><LockKeyhole size={15} /> Private caregiver data</span><p>Profiles and activity records are saved to the secure MAYA database.</p></div></aside><section className="care-main">{isAuthenticated && loading ? <SavedDataState loading /> : error ? <SavedDataState error={error} onRetry={retry} /> : showSetup ? <Onboarding patient={patient} routine={routine} isAuthenticated={isAuthenticated} saving={saving} onSaveProfile={onSaveProfile} setCareScreen={setCareScreen} /> : <CaregiverDashboard name={name} routine={visibleRoutine} activityCount={isPreview ? 3 : activityCount} recentActivities={isPreview ? [] : recentActivities} supportNotes={isPreview ? [] : supportNotes} games={visibleGames} gameSessions={visibleSessions} photoChallenges={visibleQuests} totalMemoryPoints={isPreview ? 114 : totalMemoryPoints} photoQuestMemoryPoints={isPreview ? 12 : photoQuestMemoryPoints} domainEngagement={isPreview ? previewDomains : domainEngagement} adaptiveRecommendations={isPreview ? previewRecommendations : adaptiveRecommendations} preview={isPreview} noteSaving={noteSaving} onCreateNote={onCreateNote} onReviewNote={onReviewNote} />}</section></div></main>;
}

export default function Home() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const previewRoute = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("preview") : null;
  const overviewQuery = trpc.maya.overview.useQuery(undefined, { enabled: isAuthenticated, retry: false, refetchOnWindowFocus: false });
  const playroomQuery = trpc.maya.playroom.useQuery(undefined, { enabled: isAuthenticated, retry: false, refetchOnWindowFocus: false });

  const [mode, setMode] = useState<Mode>(previewRoute === "playroom" ? "patient" : "patient");
  const [patientScreen, setPatientScreen] = useState<PatientScreen>(previewRoute === "playroom" ? "games" : "home");
  const [, setHint] = useState(false);
  const profile = overviewQuery.data?.patient ?? null;
  const routine = overviewQuery.data?.routine ?? null;
  const recentActivities = overviewQuery.data?.recentActivities ?? [];
  const supportNotes = overviewQuery.data?.supportNotes ?? [];
  const activityCount = overviewQuery.data?.activityCount ?? 0;
  const games = (playroomQuery.data?.games ?? []) as PlayroomGame[];
  const gameSessions = (playroomQuery.data?.recentSessions ?? []) as StoredGameSession[];
  const photoChallenges = (playroomQuery.data?.photoChallenges ?? []) as StoredPhotoQuest[];
  const totalMemoryPoints = playroomQuery.data?.totalMemoryPoints ?? 0;
  const photoQuestMemoryPoints = playroomQuery.data?.photoQuestMemoryPoints ?? 0;
  const domainEngagement = (playroomQuery.data?.domainEngagement ?? []) as StoredDomainEngagement[];
  const adaptiveRecommendations = (playroomQuery.data?.adaptiveRecommendations ?? []) as StoredAdaptiveRecommendation[];
  const name = profile?.preferredName ?? "friend";
  const saveProfileMutation = trpc.maya.saveProfile.useMutation();
  const recordActivityMutation = trpc.maya.recordActivity.useMutation();
  const createNoteMutation = trpc.maya.createSupportNote.useMutation();
  const reviewNoteMutation = trpc.maya.markSupportNoteReviewed.useMutation();

  useEffect(() => {
    if (isAuthenticated && !overviewQuery.isLoading && !profile && previewRoute !== "playroom") setMode("caregiver");
  }, [isAuthenticated, overviewQuery.isLoading, profile, previewRoute]);

  const saveProfile = async (input: ProfileDraft): Promise<void> => {
    try {
      const updated = await saveProfileMutation.mutateAsync(input);
      utils.maya.overview.setData(undefined, updated);
      toast.success("Caregiver-approved routine saved safely.");
    } catch (error) {
      toast.error("The routine could not be saved. Please check the connection and try again.");
      throw error;
    }
  };
  const saveActivity = async (): Promise<void> => {
    if (!isAuthenticated) { toast.message("Sign in from the caregiver view to save this activity securely."); setMode("caregiver"); return; }
    if (!profile || !routine) { toast.message("A caregiver needs to save a familiar routine first."); setMode("caregiver"); return; }
    try {
      const updated = await recordActivityMutation.mutateAsync({ patientId: profile.id, gameId: "mission_home", templateId: "morning_routine", level: 2, language: profile.preferredLanguage, completed: true, accuracyPercent: 100, hintsUsed: 0, responseTimeSeconds: 42, frustrationFlag: false, mood: "calm", syncStatus: "synced" });
      utils.maya.overview.setData(undefined, updated);
      setPatientScreen("complete");
      toast.success("Activity saved safely for the caregiver.");
    } catch {
      toast.error("This activity could not be saved. It is still safe to rest and try again later.");
    }
  };
  const createCareNote = async (): Promise<void> => {
    if (!profile) return;
    try {
      const updated = await createNoteMutation.mutateAsync({ patientId: profile.id, kind: "check_in", body: "Caregiver recorded a check-in for today’s support context." });
      utils.maya.overview.setData(undefined, updated);
      toast.success("Check-in note saved safely.");
    } catch {
      toast.error("The check-in note could not be saved. Please try again.");
    }
  };
  const reviewCareNote = async (noteId: number): Promise<void> => {
    try {
      const updated = await reviewNoteMutation.mutateAsync({ noteId });
      utils.maya.overview.setData(undefined, updated);
      toast.success("Check-in marked as reviewed.");
    } catch {
      toast.error("The review state could not be saved. Please try again.");
    }
  };

  const patientContent = (() => {
    switch (patientScreen) {
      case "today": return <TodayView setScreen={setPatientScreen} />;
      case "games": return <GamesView setScreen={setPatientScreen} />;
      case "mission": return <MissionView setScreen={setPatientScreen} setHint={setHint} />;
      case "feedback-good": return <FeedbackView good setScreen={setPatientScreen} saveActivity={saveActivity} saving={recordActivityMutation.isPending} />;
      case "feedback-support": return <FeedbackView good={false} setScreen={setPatientScreen} saveActivity={saveActivity} saving={recordActivityMutation.isPending} />;
      case "complete": return <CompletionView setScreen={setPatientScreen} pending={activityCount} />;
      case "talk": return <TalkView setScreen={setPatientScreen} />;
      case "help": return <HelpView setScreen={setPatientScreen} />;
      case "companion": return <MayaCompanion onBack={() => setPatientScreen("home")} patientId={profile?.id} />;
      case "photoquest": return <PhotoQuest onBack={() => setPatientScreen("home")} patientId={profile?.id} />;
      default: return <PatientHome name={name} ready={Boolean(profile && routine)} setScreen={setPatientScreen} openSetup={() => setMode("caregiver")} openPlayroom={() => setPatientScreen("games")} />;
    }
  })();

  const overviewError = overviewQuery.error instanceof Error ? overviewQuery.error.message : null;
  const patientView = isAuthenticated && overviewQuery.isLoading ? <PatientShell screen="home" setScreen={setPatientScreen} name="friend" pending={0}><div className="patient-view"><SavedDataState loading /></div></PatientShell> : overviewError ? <PatientShell screen="home" setScreen={setPatientScreen} name="friend" pending={0}><div className="patient-view"><SavedDataState error={overviewError} onRetry={() => void overviewQuery.refetch()} /></div></PatientShell> : <PatientShell screen={patientScreen} setScreen={setPatientScreen} name={name} pending={activityCount}>{patientContent}</PatientShell>;
  return <div className="maya-app"><div className="grain" /><ViewSwitch mode={mode} setMode={setMode} />{mode === "patient" ? patientView : <CaregiverApp patient={profile} routine={routine} isAuthenticated={isAuthenticated} loading={overviewQuery.isLoading || playroomQuery.isLoading} error={overviewError} activityCount={activityCount} recentActivities={recentActivities} supportNotes={supportNotes} games={games} gameSessions={gameSessions} photoChallenges={photoChallenges} totalMemoryPoints={totalMemoryPoints} photoQuestMemoryPoints={photoQuestMemoryPoints} domainEngagement={domainEngagement} adaptiveRecommendations={adaptiveRecommendations} saving={saveProfileMutation.isPending} noteSaving={createNoteMutation.isPending || reviewNoteMutation.isPending} onSaveProfile={saveProfile} onCreateNote={createCareNote} onReviewNote={reviewCareNote} retry={() => { void overviewQuery.refetch(); void playroomQuery.refetch(); }} />}</div>;
}
