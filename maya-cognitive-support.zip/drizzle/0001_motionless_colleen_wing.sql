CREATE TABLE `assistantMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`caregiverId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `assistantMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cameraChallenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`caregiverId` int NOT NULL,
	`prompt` varchar(160) NOT NULL,
	`targetKeywords` text NOT NULL,
	`status` enum('pending','verified','needs_retake','declined') NOT NULL DEFAULT 'pending',
	`confidencePercent` int NOT NULL DEFAULT 0,
	`awardedPoints` int NOT NULL DEFAULT 0,
	`imageStored` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `cameraChallenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameProgress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`gameId` varchar(80) NOT NULL,
	`unlockedLevel` int NOT NULL DEFAULT 1,
	`highestLevel` int NOT NULL DEFAULT 1,
	`memoryPoints` int NOT NULL DEFAULT 0,
	`totalSessions` int NOT NULL DEFAULT 0,
	`completedSessions` int NOT NULL DEFAULT 0,
	`lastPlayedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameProgress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`gameId` varchar(80) NOT NULL,
	`level` int NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`possiblePoints` int NOT NULL DEFAULT 0,
	`correctCount` int NOT NULL DEFAULT 0,
	`totalItems` int NOT NULL DEFAULT 0,
	`hintsUsed` int NOT NULL DEFAULT 0,
	`completed` boolean NOT NULL DEFAULT false,
	`durationSeconds` int NOT NULL DEFAULT 0,
	`pointsEarned` int NOT NULL DEFAULT 0,
	`occurredAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `gameSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `assistant_messages_patient_created_idx` ON `assistantMessages` (`patientId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `camera_challenges_patient_created_idx` ON `cameraChallenges` (`patientId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `game_progress_patient_game_idx` ON `gameProgress` (`patientId`,`gameId`);--> statement-breakpoint
CREATE INDEX `game_sessions_patient_occurred_idx` ON `gameSessions` (`patientId`,`occurredAt`);