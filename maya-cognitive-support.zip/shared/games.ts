export const GAME_IDS = [
  "pairing_table",
  "lantern_path",
  "daily_order",
  "market_basket",
  "word_garden",
  "village_map",
] as const;

export type GameId = (typeof GAME_IDS)[number];

export type GameDefinition = {
  id: GameId;
  name: string;
  shortName: string;
  description: string;
  icon: "cards" | "path" | "sequence" | "basket" | "garden" | "map";
  accent: "indigo" | "teal" | "clay" | "sun";
};

export const GAME_CATALOG: GameDefinition[] = [
  { id: "pairing_table", name: "Pairing Table", shortName: "Match familiar pairs", description: "Turn over two cards at a time and find the pairs.", icon: "cards", accent: "indigo" },
  { id: "lantern_path", name: "Lantern Path", shortName: "Repeat the glow", description: "Follow a small lantern path, one gentle step at a time.", icon: "path", accent: "sun" },
  { id: "daily_order", name: "Daily Order", shortName: "Put steps in order", description: "Place a familiar routine in the order that feels right.", icon: "sequence", accent: "teal" },
  { id: "market_basket", name: "Market Basket", shortName: "Find the basket items", description: "Choose the items asked for from a calm market table.", icon: "basket", accent: "clay" },
  { id: "word_garden", name: "Word Garden", shortName: "Find the matching word", description: "Match a familiar picture with its word or beginning sound.", icon: "garden", accent: "teal" },
  { id: "village_map", name: "Village Map", shortName: "Remember the landmark", description: "Notice a landmark, then choose where it appeared on the map.", icon: "map", accent: "sun" },
];

export const MAX_GAME_LEVEL = 20;

export type ProgressRuleInput = {
  level: number;
  correctCount: number;
  totalItems: number;
  hintsUsed: number;
  completed: boolean;
};

export function clampLevel(level: number) {
  return Math.max(1, Math.min(MAX_GAME_LEVEL, Math.round(level)));
}

export function calculateGameOutcome(input: ProgressRuleInput) {
  const totalItems = Math.max(1, input.totalItems);
  const accuracy = Math.round((Math.max(0, input.correctCount) / totalItems) * 100);
  const completionPoints = input.completed ? 8 : 0;
  const accuracyPoints = Math.max(0, Math.round((Math.min(100, accuracy) / 100) * 12));
  const hintAdjustment = input.hintsUsed > 0 ? Math.min(4, input.hintsUsed) : 0;
  const pointsEarned = Math.max(0, completionPoints + accuracyPoints - hintAdjustment);
  const isStrongCompletion = input.completed && accuracy >= 80 && input.hintsUsed === 0;
  const nextUnlockedLevel = isStrongCompletion ? clampLevel(input.level + 1) : clampLevel(input.level);
  return { accuracyPercent: Math.min(100, accuracy), pointsEarned, nextUnlockedLevel, isStrongCompletion };
}

export function isGameId(value: string): value is GameId {
  return GAME_IDS.includes(value as GameId);
}

/**
 * A deterministic, auditable complexity plan for all ten levels. Each game
 * changes only one or two visible dimensions at a time so a harder level never
 * becomes an unrelated interaction model.
 */
export function getGameLevelSpec(gameId: GameId, level: number) {
  const safeLevel = clampLevel(level);
  switch (gameId) {
    case "pairing_table":
      return { primaryCount: Math.min(6, 2 + Math.floor((safeLevel - 1) / 2)), secondaryCount: 0, columns: safeLevel >= 7 ? 4 : 3 };
    case "lantern_path":
      return { primaryCount: Math.min(8, 3 + Math.floor((safeLevel - 1) / 2)), secondaryCount: 4, columns: 4 };
    case "daily_order":
      return { primaryCount: Math.min(6, 2 + Math.floor((safeLevel - 1) / 2)), secondaryCount: 0, columns: 1 };
    case "market_basket":
      return { primaryCount: Math.min(4, 1 + Math.floor((safeLevel - 1) / 3)), secondaryCount: Math.min(10, 5 + safeLevel - 1), columns: safeLevel >= 7 ? 5 : 4 };
    case "word_garden":
      return { primaryCount: Math.min(4, 2 + Math.floor((safeLevel - 1) / 3)), secondaryCount: 1, columns: 4 };
    case "village_map": {
      const cells = safeLevel < 4 ? 4 : safeLevel < 8 ? 6 : 9;
      return { primaryCount: cells, secondaryCount: 1, columns: cells === 4 ? 2 : 3 };
    }
  }
}
