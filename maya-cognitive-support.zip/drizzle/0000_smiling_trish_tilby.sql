CREATE TABLE `activityEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`gameId` varchar(80) NOT NULL,
	`templateId` varchar(80) NOT NULL,
	`level` int NOT NULL,
	`language` varchar(48) NOT NULL,
	`completed` boolean NOT NULL DEFAULT false,
	`accuracyPercent` int NOT NULL DEFAULT 0,
	`hintsUsed` int NOT NULL DEFAULT 0,
	`responseTimeSeconds` int NOT NULL DEFAULT 0,
	`frustrationFlag` boolean NOT NULL DEFAULT false,
	`mood` varchar(32) NOT NULL DEFAULT 'calm',
	`syncStatus` enum('pending','synced') NOT NULL DEFAULT 'synced',
	`occurredAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activityEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patientRoutines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`morningRoutine` text NOT NULL,
	`medicineLocation` varchar(255) NOT NULL,
	`approvedContent` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patientRoutines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`caregiverId` int NOT NULL,
	`preferredName` varchar(120) NOT NULL,
	`preferredLanguage` varchar(48) NOT NULL DEFAULT 'English',
	`consentStatus` enum('pending','confirmed','withdrawn') NOT NULL DEFAULT 'pending',
	`isArchived` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `supportNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`authorId` int NOT NULL,
	`kind` enum('check_in','care_note') NOT NULL DEFAULT 'check_in',
	`body` text NOT NULL,
	`reviewed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`reviewedAt` timestamp,
	CONSTRAINT `supportNotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE INDEX `activity_events_patient_occurred_idx` ON `activityEvents` (`patientId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `patient_routines_patient_idx` ON `patientRoutines` (`patientId`);--> statement-breakpoint
CREATE INDEX `patients_caregiver_idx` ON `patients` (`caregiverId`);--> statement-breakpoint
CREATE INDEX `support_notes_patient_idx` ON `supportNotes` (`patientId`);