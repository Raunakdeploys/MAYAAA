import { describe, expect, it } from "vitest";
import { calculateGameOutcome, GAME_CATALOG } from "./games";
import { createRepresentativeCompletion, normalizeGameCompletion } from "./gameCompletion";

describe("MAYA game completion contract", () => {
  it("normalizes unsafe client values before any game result is saved", () => {
    const normalized = normalizeGameCompletion("market_basket", 16, { correctCount: 99, totalItems: 0, hintsUsed: 99, title: "Done", detail: "Done" });
    expect(normalized.level).toBe(10);
    expect(normalized.totalItems).toBe(1);
    expect(normalized.correctCount).toBe(1);
    expect(normalized.hintsUsed).toBe(12);
  });

  it("creates a valid save-ready completion for all six games at low, middle, and high levels", () => {
    for (const game of GAME_CATALOG) {
      for (const level of [1, 5, 10]) {
        const completion = createRepresentativeCompletion(game.id, level);
        const outcome = calculateGameOutcome({ ...completion, completed: true });
        expect(completion.gameId).toBe(game.id);
        expect(completion.level).toBe(level);
        expect(completion.correctCount).toBe(completion.totalItems);
        expect(outcome.pointsEarned).toBeGreaterThan(0);
      }
    }
  });
});
