import { describe, expect, it } from "vitest";
import { resolvePlayroomProgress } from "./playroomProgress";

describe("MAYA Playroom server progression service", () => {
  it("adds earned points and unlocks the next level after a strong saved session", () => {
    const result = resolvePlayroomProgress(
      { unlockedLevel: 3, highestLevel: 3, memoryPoints: 24, totalSessions: 2, completedSessions: 2 },
      { level: 3, correctCount: 4, totalItems: 4, hintsUsed: 0, completed: true },
    );

    expect(result.next.unlockedLevel).toBe(4);
    expect(result.next.highestLevel).toBe(3);
    expect(result.next.memoryPoints).toBeGreaterThan(24);
    expect(result.next.totalSessions).toBe(3);
  });

  it("keeps the unlocked level and never removes points after a supported attempt", () => {
    const result = resolvePlayroomProgress(
      { unlockedLevel: 6, highestLevel: 6, memoryPoints: 81, totalSessions: 6, completedSessions: 6 },
      { level: 6, correctCount: 1, totalItems: 5, hintsUsed: 3, completed: true },
    );

    expect(result.next.unlockedLevel).toBe(6);
    expect(result.next.memoryPoints).toBeGreaterThanOrEqual(81);
    expect(result.next.completedSessions).toBe(7);
  });
});
