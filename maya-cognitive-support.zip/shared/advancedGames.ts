import type { GameId } from "./games";

export const CORE_LEVEL_COUNT = 20;

export type CognitiveDomain = "visual_association" | "working_memory" | "routine_planning" | "selective_attention" | "language_reminiscence" | "spatial_orientation";
export type GameMode = "recognise" | "reconstruct" | "prioritise" | "filter" | "connect" | "navigate";

export type AdvancedGameDefinition = {
  id: GameId;
  name: string;
  genre: string;
  domain: CognitiveDomain;
  caregiverPersonalisation: string[];
  purpose: string;
  bands: readonly { levels: readonly [number, number]; name: string; experience: string }[];
};

export const ADVANCED_GAME_CATALOG: readonly AdvancedGameDefinition[] = [
  {
    id: "pairing_table", name: "Memory Mosaic", genre: "Visual association studio", domain: "visual_association",
    caregiverPersonalisation: ["approved people", "familiar objects", "meaningful places"],
    purpose: "Recognise and reconnect familiar visual relationships through a calm mosaic-building task.",
    bands: [{ levels: [1, 4], name: "Notice", experience: "Find obvious pairs with picture and spoken-name cues." }, { levels: [5, 8], name: "Link", experience: "Reconnect a person, place, or object after brief separation." }, { levels: [9, 12], name: "Rebuild", experience: "Restore a small three-part familiar scene." }, { levels: [13, 16], name: "Compare", experience: "Choose a meaningful match among similar gentle alternatives." }, { levels: [17, 20], name: "Mosaic", experience: "Complete a four-part memory mosaic with optional cues." }],
  },
  {
    id: "lantern_path", name: "Lantern Echo", genre: "Rhythm and sequence recall", domain: "working_memory",
    caregiverPersonalisation: ["familiar sounds", "preferred colours", "home landmarks"],
    purpose: "Follow a rhythmic lantern trail with slow, repeatable sequences and no timed response.",
    bands: [{ levels: [1, 4], name: "Glow", experience: "Echo short two-to-three lantern patterns." }, { levels: [5, 8], name: "Trail", experience: "Hold and repeat four-to-five gentle path steps." }, { levels: [9, 12], name: "Rhythm", experience: "Recall patterns with a familiar sound or colour cue." }, { levels: [13, 16], name: "Crossroads", experience: "Keep the sequence while one quiet decoy appears." }, { levels: [17, 20], name: "Homeward", experience: "Rebuild a seven-step path at a self-chosen pace." }],
  },
  {
    id: "daily_order", name: "Routine Studio", genre: "Practical planning and sequencing", domain: "routine_planning",
    caregiverPersonalisation: ["approved routine steps", "medicine location", "daily preferences"],
    purpose: "Arrange familiar, caregiver-approved moments into a personal daily story rather than recall arbitrary lists.",
    bands: [{ levels: [1, 4], name: "First and next", experience: "Choose the next step in a two-to-three item routine." }, { levels: [5, 8], name: "Morning", experience: "Arrange a four-step personal routine with a visible first cue." }, { levels: [9, 12], name: "Prepare", experience: "Prioritise essentials and place a pause or rest moment." }, { levels: [13, 16], name: "Plan", experience: "Reconstruct a six-step routine from mixed cards." }, { levels: [17, 20], name: "Day story", experience: "Build a longer flexible routine while preserving caregiver-approved anchors." }],
  },
  {
    id: "market_basket", name: "Market Detective", genre: "Selective-attention scavenger game", domain: "selective_attention",
    caregiverPersonalisation: ["familiar foods", "household objects", "local market items"],
    purpose: "Select meaningful targets while calmly ignoring an increasing number of non-targets—without penalties for a miss.",
    bands: [{ levels: [1, 4], name: "Find", experience: "Choose one familiar target from a small uncrowded table." }, { levels: [5, 8], name: "Basket", experience: "Gather two-to-three items with picture and word cues." }, { levels: [9, 12], name: "Market row", experience: "Choose targets among related but distinct items." }, { levels: [13, 16], name: "Shopping list", experience: "Remember a short approved shopping list before searching." }, { levels: [17, 20], name: "Market day", experience: "Plan and fill a four-item basket with optional spoken support." }],
  },
  {
    id: "word_garden", name: "Story Garden", genre: "Language and reminiscence storytelling", domain: "language_reminiscence",
    caregiverPersonalisation: ["family names", "languages", "favourite sayings", "memory prompts"],
    purpose: "Grow a short familiar story by linking words, images, sounds, and caregiver-approved personal prompts.",
    bands: [{ levels: [1, 4], name: "Name", experience: "Match a familiar picture to its spoken or written word." }, { levels: [5, 8], name: "Beginning", experience: "Choose a beginning sound or word partner with voice support." }, { levels: [9, 12], name: "Bloom", experience: "Link two words from a familiar scene or memory." }, { levels: [13, 16], name: "Sentence", experience: "Choose a gentle next phrase to complete a familiar thought." }, { levels: [17, 20], name: "Garden story", experience: "Arrange a four-part personal story with any desired cues." }],
  },
  {
    id: "village_map", name: "Village Navigator", genre: "Spatial orientation and route planning", domain: "spatial_orientation",
    caregiverPersonalisation: ["home landmarks", "safe local places", "family locations"],
    purpose: "Navigate calm illustrated places by recognising landmarks and rebuilding short familiar routes without real-world wayfinding claims.",
    bands: [{ levels: [1, 4], name: "Landmark", experience: "Find one recognisable landmark on a small map." }, { levels: [5, 8], name: "Neighbourhood", experience: "Choose between two familiar route directions." }, { levels: [9, 12], name: "Path", experience: "Rebuild a three-stop illustrated route." }, { levels: [13, 16], name: "Visit", experience: "Match a landmark to a remembered place after a brief cover." }, { levels: [17, 20], name: "Village story", experience: "Plan a four-stop picture route with landmark cues available." }],
  },
];

export type AdvancedLevelSpec = {
  gameId: GameId;
  level: number;
  band: string;
  mode: GameMode;
  targetCount: number;
  distractorCount: number;
  recallSpan: number;
  cueBudget: number;
  promptStyle: "picture" | "picture_word" | "spoken_picture" | "mixed";
};

const modes: Record<GameId, readonly GameMode[]> = {
  pairing_table: ["recognise", "recognise", "reconstruct", "reconstruct", "connect"],
  lantern_path: ["recognise", "reconstruct", "reconstruct", "filter", "navigate"],
  daily_order: ["prioritise", "prioritise", "reconstruct", "reconstruct", "connect"],
  market_basket: ["recognise", "filter", "filter", "prioritise", "connect"],
  word_garden: ["recognise", "connect", "connect", "reconstruct", "reconstruct"],
  village_map: ["recognise", "navigate", "navigate", "reconstruct", "connect"],
};

export function clampCoreLevel(level: number) { return Math.max(1, Math.min(CORE_LEVEL_COUNT, Math.round(level))); }

export function getAdvancedLevelSpec(gameId: GameId, level: number): AdvancedLevelSpec {
  const safeLevel = clampCoreLevel(level);
  const bandIndex = Math.floor((safeLevel - 1) / 4);
  const band = ADVANCED_GAME_CATALOG.find(game => game.id === gameId)!.bands[bandIndex]!;
  const withinBand = (safeLevel - 1) % 4;
  const highLevel = safeLevel >= 13;
  return {
    gameId, level: safeLevel, band: band.name, mode: modes[gameId][bandIndex]!,
    targetCount: Math.min(6, 2 + bandIndex + (withinBand >= 2 ? 1 : 0)),
    distractorCount: Math.max(0, bandIndex * 2 + (withinBand >= 1 ? 1 : 0)),
    recallSpan: Math.min(8, 2 + bandIndex + withinBand),
    cueBudget: highLevel ? 2 : 3,
    promptStyle: safeLevel <= 4 ? "picture" : safeLevel <= 8 ? "picture_word" : safeLevel <= 12 ? "spoken_picture" : "mixed",
  };
}

export type AdaptiveObservation = { level: number; accuracyPercent: number; hintsUsed: number; completed: boolean; consecutiveStruggles: number };
export type AdaptiveRecommendation =
  | { kind: "advance"; nextLevel: number; reason: string }
  | { kind: "repeat_with_new_content"; nextLevel: number; reason: string }
  | { kind: "bridge_assessment"; lowerLevel: number; upperLevel: number; difficultyRatio: number; reason: string }
  | { kind: "gentler_choice"; nextLevel: number; reason: string };

/**
 * This is a transparent engagement algorithm, not a clinical assessment. It
 * creates a bridge task only after repeated difficulty, then uses its result to
 * choose content and support—not to infer health status.
 */
export function recommendNextAdaptiveExperience(observation: AdaptiveObservation): AdaptiveRecommendation {
  const level = clampCoreLevel(observation.level);
  const strong = observation.completed && observation.accuracyPercent >= 85 && observation.hintsUsed <= 1;
  if (strong) return { kind: "advance", nextLevel: clampCoreLevel(level + 1), reason: "The last challenge felt comfortable with little support." };
  const repeatedDifficulty = observation.consecutiveStruggles >= 2 || (observation.accuracyPercent < 60 && observation.hintsUsed >= 2);
  if (repeatedDifficulty && level > 1) return { kind: "bridge_assessment", lowerLevel: level - 1, upperLevel: level, difficultyRatio: 0.5, reason: "Let us try a gentler bridge between two nearby challenges." };
  if (observation.accuracyPercent < 60) return { kind: "gentler_choice", nextLevel: Math.max(1, level - 1), reason: "A simpler version can keep this moment comfortable." };
  return { kind: "repeat_with_new_content", nextLevel: level, reason: "A fresh version at this level can help the pattern feel familiar." };
}
