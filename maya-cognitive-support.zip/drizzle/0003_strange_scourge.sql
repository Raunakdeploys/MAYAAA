CREATE TABLE `domainEngagement` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`domain` enum('visual_association','working_memory','routine_planning','selective_attention','language_reminiscence','spatial_orientation') NOT NULL,
	`momentsCompleted` int NOT NULL DEFAULT 0,
	`momentsWithSupport` int NOT NULL DEFAULT 0,
	`totalParticipationPoints` int NOT NULL DEFAULT 0,
	`lastEngagedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `domainEngagement_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `domain_engagement_patient_domain_idx` ON `domainEngagement` (`patientId`,`domain`);