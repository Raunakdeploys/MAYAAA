import { getGameLevelSpec, type GameId } from "./games";

export type GameCompletionDraft = {
  correctCount: number;
  totalItems: number;
  hintsUsed: number;
  title: string;
  detail: string;
};

export type NormalizedGameCompletion = GameCompletionDraft & {
  gameId: GameId;
  level: number;
};

/** Shared gate before every browser game hands an outcome to the persisted-session mutation. */
export function normalizeGameCompletion(gameId: GameId, level: number, draft: GameCompletionDraft): NormalizedGameCompletion {
  const safeTotal = Math.max(1, Math.min(40, Math.round(draft.totalItems)));
  return {
    ...draft,
    gameId,
    level: Math.max(1, Math.min(10, Math.round(level))),
    totalItems: safeTotal,
    correctCount: Math.max(0, Math.min(safeTotal, Math.round(draft.correctCount))),
    hintsUsed: Math.max(0, Math.min(12, Math.round(draft.hintsUsed))),
  };
}

/** A deterministic happy-path completion used to verify representative levels for every game. */
export function createRepresentativeCompletion(gameId: GameId, level: number) {
  const spec = getGameLevelSpec(gameId, level);
  const totalItems = gameId === "market_basket" || gameId === "pairing_table" || gameId === "lantern_path" || gameId === "daily_order" ? spec.primaryCount : 1;
  return normalizeGameCompletion(gameId, level, {
    correctCount: totalItems,
    totalItems,
    hintsUsed: 0,
    title: "Moment complete",
    detail: "A representative game completion reached the shared session pipeline.",
  });
}
