CREATE TABLE `adaptiveGameRecommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`gameId` varchar(80) NOT NULL,
	`kind` enum('advance','repeat_with_new_content','bridge_assessment','gentler_choice') NOT NULL,
	`currentLevel` int NOT NULL,
	`recommendedLevel` int NOT NULL,
	`lowerLevel` int,
	`upperLevel` int,
	`difficultyRatioPercent` int,
	`reason` varchar(255) NOT NULL,
	`status` enum('available','started','completed','dismissed') NOT NULL DEFAULT 'available',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`resolvedAt` timestamp,
	CONSTRAINT `adaptiveGameRecommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `gameContentCards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`caregiverId` int NOT NULL,
	`category` enum('person','place','object','food','routine','saying','sound') NOT NULL,
	`label` varchar(120) NOT NULL,
	`language` varchar(48) NOT NULL DEFAULT 'English',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `gameContentCards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `gameProgress` ADD `consecutiveStruggles` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `gameProgress` ADD `recommendedLevel` int;--> statement-breakpoint
ALTER TABLE `gameProgress` ADD `recommendationKind` enum('advance','repeat_with_new_content','bridge_assessment','gentler_choice');--> statement-breakpoint
ALTER TABLE `gameProgress` ADD `lastComfortBand` varchar(48);--> statement-breakpoint
ALTER TABLE `gameSessions` ADD `sessionKind` enum('standard','bridge_assessment') DEFAULT 'standard' NOT NULL;--> statement-breakpoint
ALTER TABLE `gameSessions` ADD `contentSource` enum('caregiver_approved','general') DEFAULT 'general' NOT NULL;--> statement-breakpoint
ALTER TABLE `gameSessions` ADD `comfortChoice` enum('steady','needed_support','prefer_gentler','stopped_early') DEFAULT 'steady' NOT NULL;--> statement-breakpoint
CREATE INDEX `adaptive_recommendations_patient_game_idx` ON `adaptiveGameRecommendations` (`patientId`,`gameId`);--> statement-breakpoint
CREATE INDEX `game_content_cards_patient_category_idx` ON `gameContentCards` (`patientId`,`category`);