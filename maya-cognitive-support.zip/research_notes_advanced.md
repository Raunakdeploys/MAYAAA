# MAYA Advanced Cognitive-Engagement Evidence Notes

## Evidence framing

MAYA is an **engagement and cognitive-stimulation companion**, not a diagnostic device, medical treatment, or guarantee of cognitive improvement. In-product metrics must describe **game interaction**—such as completion, support used, comfort choice, and personal challenge fit—and must never be labelled as cognitive health, dementia severity, clinical risk, or treatment response.

## Findings that guide the game system

| Finding | Design implication for MAYA | Source |
|---|---|---|
| Cognitive training is structured guided practice that can target specific abilities. A 2019 Cochrane review found small-to-moderate post-treatment effects on global cognition and verbal semantic fluency versus control, while many longer-term and functional outcomes remained uncertain. | Offer specific but non-punitive genres. Do not claim to slow disease progression, restore memory, or improve daily independence. | [Bahar-Fuchs et al., 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6433473/) |
| Cognitive stimulation encompasses enjoyable, varied activities that stimulate thinking, concentration, memory, communication, and social interaction. | Use a varied six-genre library with meaningful familiar content rather than drill-like repetition alone. | [Woods et al., 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC9891430/) |
| The 2023 Cochrane review of cognitive stimulation included 37 RCTs and 2,766 participants, reporting modest short-term cognitive benefit and stronger evidence for communication/social interaction; heterogeneity and limited longer-term data remain important constraints. | Present participation, choice, and support patterns to caregivers. Keep an explicit evidence note that app-level scores are not clinical measures. | [Woods et al., 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC9891430/) |
| Across the studies, frequency and initial severity may matter, but the review treats these subgroup findings cautiously. Most evidence is from group programmes; evidence for individual digital delivery remains limited. | Make adaptive difficulty a usability and engagement feature—not an evidence-backed clinical prescription. Add caregiver controls for shorter sessions, pauses, and content changes. | [Cochrane Library, 2023](https://www.cochranelibrary.com/cdsr/doi/10.1002/14651858.CD005562.pub3/full) |

## Non-negotiable product safeguards

> A repeated incorrect answer is treated as a **signal to simplify or offer support**, never as failure, a health indicator, or a reason to deduct progress.

The game system should use one task at a time, large targets, no countdowns, optional rest/pause, plain language, familiar caregiver-approved content, a visible exit route, and immediate affirming feedback. Camera challenges remain opt-in; source images are processed for the moment and not retained by the product.

## Interaction guidance applied to MAYA

The Alzheimer's Society advises direct, specific language; clear routes back to home or the task start; visible navigation; clear stage breaks; high contrast; plain text backgrounds; and larger readable text. AbilityNet additionally recommends predictable navigation order, descriptive headings, explicit outcomes, adjustable text, no reliance on colour alone, reduced distraction, and sufficient processing time. MAYA’s 20+ level games therefore keep each screen to one decision, use a persistent **Pause / Home / Try a gentler version** handrail, avoid auto-advance and timers, and treat each assessment level as optional supported practice rather than a test.

Sources: [Alzheimer's Society, 2024](https://www.alzheimers.org.uk/blog/how-design-website-someone-affected-dementia); [AbilityNet, 2025](https://abilitynet.org.uk/factsheets/designing-dementia).

## Measurement language for MAYA

Use phrases such as **“comfortable challenge range,” “recent play pattern,” “supports that helped,” “preferred activity,” and “moments completed.”** Avoid “brain score,” “cognitive decline,” “dementia score,” “treatment response,” or “health points.” Memory points remain a game progression currency only.
