import { COOKIE_NAME } from "@shared/const";
import { mayaActivityInput, mayaAssistantInput, mayaCameraChallengeInput, mayaCameraVerifyInput, mayaGameSessionInput, mayaPatientInput, mayaProfileInput, mayaReviewNoteInput, mayaSupportNoteInput } from "./mayaSchemas";
import { appendMayaAssistantMessage, createMayaCameraChallenge, createMayaSupportNote, getMayaAssistantHistory, getMayaOverview, getMayaPlayroom, getOwnedCameraChallenge, markMayaSupportNoteReviewed, recordMayaActivity, recordMayaGameSession, saveMayaCameraVerification, saveMayaProfile } from "./db";
import { createCompanionReply, verifyPhotoQuestImage } from "./mayaCompanion";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  maya: router({
    overview: protectedProcedure.query(({ ctx }) => getMayaOverview(ctx.user.id)),
    saveProfile: protectedProcedure.input(mayaProfileInput).mutation(({ ctx, input }) => saveMayaProfile(ctx.user.id, input)),
    recordActivity: protectedProcedure.input(mayaActivityInput).mutation(({ ctx, input }) => recordMayaActivity(ctx.user.id, input)),
    createSupportNote: protectedProcedure.input(mayaSupportNoteInput).mutation(({ ctx, input }) => createMayaSupportNote(ctx.user.id, input)),
    markSupportNoteReviewed: protectedProcedure.input(mayaReviewNoteInput).mutation(({ ctx, input }) => markMayaSupportNoteReviewed(ctx.user.id, input.noteId)),
    playroom: protectedProcedure.query(({ ctx }) => getMayaPlayroom(ctx.user.id)),
    recordGameSession: protectedProcedure.input(mayaGameSessionInput).mutation(({ ctx, input }) => recordMayaGameSession(ctx.user.id, input)),
    createCameraChallenge: protectedProcedure.input(mayaCameraChallengeInput).mutation(({ ctx, input }) => createMayaCameraChallenge(ctx.user.id, input)),
    assistantHistory: protectedProcedure.input(mayaPatientInput).query(({ ctx, input }) => getMayaAssistantHistory(ctx.user.id, input.patientId)),
    assistantChat: protectedProcedure.input(mayaAssistantInput).mutation(async ({ ctx, input }) => {
      const overview = await getMayaOverview(ctx.user.id);
      if (!overview.patient || overview.patient.id !== input.patientId) throw new Error("Patient record was not found for this caregiver");
      await appendMayaAssistantMessage(ctx.user.id, input.patientId, "user", input.message);
      const reply = await createCompanionReply({
        preferredName: overview.patient.preferredName,
        preferredLanguage: overview.patient.preferredLanguage,
        approvedContent: overview.routine?.approvedContent ?? [],
        message: input.message,
      });
      await appendMayaAssistantMessage(ctx.user.id, input.patientId, "assistant", reply);
      return { reply };
    }),
    verifyCameraChallenge: protectedProcedure.input(mayaCameraVerifyInput).mutation(async ({ ctx, input }) => {
      const challenge = await getOwnedCameraChallenge(ctx.user.id, input.challengeId);
      if (!challenge) throw new Error("Photo Quest challenge was not found for this caregiver");
      const result = await verifyPhotoQuestImage({ prompt: challenge.prompt, targetKeywords: JSON.parse(challenge.targetKeywords) as string[], imageDataUrl: input.imageDataUrl });
      const playroom = await saveMayaCameraVerification(ctx.user.id, input.challengeId, result);
      return { ...result, awardedPoints: result.verified ? 12 : 0, playroom };
    }),
  }),
});

export type AppRouter = typeof appRouter;
