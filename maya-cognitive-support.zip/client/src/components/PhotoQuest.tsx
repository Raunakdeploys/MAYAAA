import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Camera, CheckCircle2, ImagePlus, Leaf, LoaderCircle, RefreshCw, ShieldCheck, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

type PhotoQuestProps = { onBack: () => void; patientId?: number };
type Quest = { id: number; prompt: string; targetKeywords: string[] };

export default function PhotoQuest({ onBack, patientId }: PhotoQuestProps) {
  const { isAuthenticated } = useAuth();
  const createQuest = trpc.maya.createCameraChallenge.useMutation();
  const verifyQuest = trpc.maya.verifyCameraChallenge.useMutation();
  const utils = trpc.useUtils();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [quest, setQuest] = useState<Quest | null>(null);
  const [consented, setConsented] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [capture, setCapture] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ message: string; awardedPoints: number } | null>(null);
  const stopCamera = () => { streamRef.current?.getTracks().forEach(track => track.stop()); streamRef.current = null; setCameraOpen(false); };
  useEffect(() => () => stopCamera(), []);
  const prepareQuest = async () => {
    if (!isAuthenticated || !patientId) { startLogin(); return; }
    try {
      const created = await createQuest.mutateAsync({ patientId, prompt: "Find a mango tree", targetKeywords: ["mango tree", "mango", "tree"] });
      setQuest({ id: created.id, prompt: created.prompt, targetKeywords: ["mango tree", "mango", "tree"] }); setFeedback(null); setCapture(null);
    } catch { toast.error("A caregiver profile is needed before Photo Quest can begin."); }
  };
  const openCamera = async () => {
    if (!consented) { toast.message("Please confirm before MAYA opens the camera."); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 960 }, height: { ideal: 720 } }, audio: false });
      streamRef.current = stream; if (videoRef.current) videoRef.current.srcObject = stream; setCameraOpen(true);
    } catch { toast.error("MAYA could not open the camera. Please allow camera access or try another browser."); }
  };
  const takePhoto = () => {
    const video = videoRef.current; if (!video) return;
    const canvas = document.createElement("canvas"); canvas.width = video.videoWidth || 960; canvas.height = video.videoHeight || 720;
    canvas.getContext("2d")?.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCapture(canvas.toDataURL("image/jpeg", 0.8)); stopCamera();
  };
  const checkPhoto = async () => {
    if (!quest || !capture) return;
    try {
      const result = await verifyQuest.mutateAsync({ challengeId: quest.id, imageDataUrl: capture });
      utils.maya.playroom.setData(undefined, result.playroom);
      setFeedback({ message: result.response, awardedPoints: result.awardedPoints });
    } catch { toast.error("MAYA could not check that photo right now. It has not been saved; you can try again."); }
  };
  return <section className="photoquest-shell"><button className="play-back" onClick={onBack}><ArrowLeft size={17} /> Back to home</button><header className="photoquest-header"><div><p className="eyebrow">Photo Quest</p><h1>Find one familiar thing nearby.</h1><p>A gentle, caregiver-approved camera challenge. MAYA only checks this one photo and keeps the result—not the photo itself.</p></div><span><Leaf size={23} /></span></header>{!quest ? <div className="photoquest-start"><ImagePlus size={34} /><h2>Today’s prompt: a mango tree.</h2><p>A caregiver starts the quest. The camera stays off until the person chooses to open it.</p><button className="play-primary" onClick={() => void prepareQuest()} disabled={createQuest.isPending}>{createQuest.isPending ? "Preparing…" : "Prepare Photo Quest"}</button></div> : feedback ? <div className="photoquest-result"><CheckCircle2 size={35} /><p className="eyebrow">Photo checked</p><h2>{feedback.message}</h2><strong className="photoquest-points">{feedback.awardedPoints ? `+${feedback.awardedPoints} memory points saved` : "No points changed — you can retake the Photo Quest anytime."}</strong><p>The captured photo was not retained by MAYA. A caregiver can see the result and any earned memory points.</p><button className="play-primary" onClick={onBack}>Return home</button></div> : <div className="photoquest-card"><div className="quest-prompt"><span>Today’s Photo Quest</span><h2>{quest.prompt}</h2></div>{!capture && !cameraOpen && <><label className="photoquest-consent"><input type="checkbox" checked={consented} onChange={event => setConsented(event.target.checked)} /><span><ShieldCheck size={21} /><strong>I agree to open the camera for this one Photo Quest.</strong><small>The camera will turn off after I take a photo.</small></span></label><button className="photoquest-camera-button" onClick={() => void openCamera()} disabled={!consented}><Camera size={22} /> Open camera</button></>}{cameraOpen && <div className="camera-stage"><video ref={videoRef} autoPlay playsInline muted /><div className="camera-actions"><button onClick={takePhoto}><Camera size={19} /> Take photo</button><button className="play-secondary" onClick={stopCamera}><X size={18} /> Close camera</button></div></div>}{capture && <div className="photo-preview"><img src={capture} alt="Your captured Photo Quest image" /><div><button className="play-secondary" onClick={() => { setCapture(null); setFeedback(null); }}><RefreshCw size={16} /> Retake</button><button className="play-primary" onClick={() => void checkPhoto()} disabled={verifyQuest.isPending}>{verifyQuest.isPending ? <><LoaderCircle className="animate-spin" size={16} /> Checking…</> : "Check this photo"}</button></div></div>}</div>}</section>;
}
