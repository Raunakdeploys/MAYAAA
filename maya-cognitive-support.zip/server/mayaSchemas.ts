import { z } from "zod";
import { GAME_IDS } from "../shared/games";

const shortText = (max: number) => z.string().trim().min(1).max(max);

/** Caregiver-approved content is required before Maya can create a personal routine. */
export const mayaProfileInput = z.object({
  patientId: z.number().int().positive().optional(),
  preferredName: shortText(120),
  preferredLanguage: shortText(48),
  morningRoutine: shortText(2_000),
  medicineLocation: shortText(255),
  approvedContent: z.array(shortText(120)).min(1).max(40),
});

/** Activity telemetry is constrained to non-clinical engagement fields only. */
export const mayaActivityInput = z.object({
  patientId: z.number().int().positive(),
  gameId: shortText(80),
  templateId: shortText(80),
  level: z.number().int().min(1).max(6),
  language: shortText(48),
  completed: z.boolean(),
  accuracyPercent: z.number().int().min(0).max(100),
  hintsUsed: z.number().int().min(0).max(20),
  responseTimeSeconds: z.number().int().min(0).max(7_200),
  frustrationFlag: z.boolean(),
  mood: shortText(32),
  syncStatus: z.enum(["pending", "synced"]),
});

export const mayaSupportNoteInput = z.object({
  patientId: z.number().int().positive(),
  kind: z.enum(["check_in", "care_note"]),
  body: shortText(4_000),
});

export const mayaReviewNoteInput = z.object({
  noteId: z.number().int().positive(),
});

export const mayaGameSessionInput = z.object({
  patientId: z.number().int().positive(),
  gameId: z.enum(GAME_IDS),
  level: z.number().int().min(1).max(20),
  correctCount: z.number().int().min(0).max(40),
  totalItems: z.number().int().min(1).max(40),
  hintsUsed: z.number().int().min(0).max(12),
  completed: z.boolean(),
  durationSeconds: z.number().int().min(0).max(3_600),
  sessionKind: z.enum(["standard", "bridge_assessment"]).default("standard"),
  contentSource: z.enum(["caregiver_approved", "general"]).default("general"),
  comfortChoice: z.enum(["steady", "needed_support", "prefer_gentler", "stopped_early"]).default("steady"),
});

export const mayaAssistantInput = z.object({
  patientId: z.number().int().positive(),
  message: shortText(800),
});

export const mayaPatientInput = z.object({
  patientId: z.number().int().positive(),
});

export const mayaCameraChallengeInput = z.object({
  patientId: z.number().int().positive(),
  prompt: shortText(160),
  targetKeywords: z.array(shortText(48)).min(1).max(6),
});

export const mayaCameraVerifyInput = z.object({
  challengeId: z.number().int().positive(),
  imageDataUrl: z.string().regex(/^data:image\/(jpeg|png|webp);base64,/, "A captured image is required").max(2_500_000),
});

export type MayaProfileInput = z.infer<typeof mayaProfileInput>;
export type MayaActivityInput = z.infer<typeof mayaActivityInput>;
export type MayaSupportNoteInput = z.infer<typeof mayaSupportNoteInput>;
export type MayaGameSessionInput = z.infer<typeof mayaGameSessionInput>;
export type MayaAssistantInput = z.infer<typeof mayaAssistantInput>;
export type MayaPatientInput = z.infer<typeof mayaPatientInput>;
export type MayaCameraChallengeInput = z.infer<typeof mayaCameraChallengeInput>;
export type MayaCameraVerifyInput = z.infer<typeof mayaCameraVerifyInput>;
