import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { activityEvents, adaptiveGameRecommendations, assistantMessages, cameraChallenges, domainEngagement, gameContentCards, gameProgress, gameSessions, InsertUser, patients, patientRoutines, supportNotes, users } from "../drizzle/schema";
import { ENV } from './_core/env';
import { GAME_CATALOG } from "../shared/games";
import { ADVANCED_GAME_CATALOG } from "../shared/advancedGames";
import { resolvePlayroomProgress } from "./playroomProgress";
import type { MayaActivityInput, MayaCameraChallengeInput, MayaGameSessionInput, MayaProfileInput, MayaSupportNoteInput } from "./mayaSchemas";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is temporarily unavailable");
  return db;
}

async function getOwnedPatient(caregiverId: number, patientId: number) {
  const db = await requireDb();
  const result = await db
    .select()
    .from(patients)
    .where(and(eq(patients.id, patientId), eq(patients.caregiverId, caregiverId), eq(patients.isArchived, false)))
    .limit(1);
  return result[0];
}

function parseApprovedContent(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) && parsed.every(item => typeof item === "string") ? parsed : [];
  } catch {
    return [];
  }
}

/** Fetch only data that belongs to the authenticated caregiver. */
export async function getMayaOverview(caregiverId: number) {
  const db = await requireDb();
  const patientRows = await db
    .select()
    .from(patients)
    .where(and(eq(patients.caregiverId, caregiverId), eq(patients.isArchived, false)))
    .orderBy(desc(patients.updatedAt))
    .limit(1);
  const patient = patientRows[0];

  if (!patient) {
    return { patient: null, routine: null, activityCount: 0, recentActivities: [], supportNotes: [] };
  }

  const [routineRows, recentActivities, recentSupportNotes] = await Promise.all([
    db.select().from(patientRoutines).where(eq(patientRoutines.patientId, patient.id)).orderBy(desc(patientRoutines.updatedAt)).limit(1),
    db.select().from(activityEvents).where(eq(activityEvents.patientId, patient.id)).orderBy(desc(activityEvents.occurredAt)).limit(10),
    db.select().from(supportNotes).where(eq(supportNotes.patientId, patient.id)).orderBy(desc(supportNotes.createdAt)).limit(10),
  ]);
  const routine = routineRows[0];
  const activityCount = recentActivities.length;

  return {
    patient,
    routine: routine ? { ...routine, approvedContent: parseApprovedContent(routine.approvedContent) } : null,
    activityCount,
    recentActivities,
    supportNotes: recentSupportNotes,
  };
}

/** Create or update an approved patient routine without exposing another caregiver's record. */
export async function saveMayaProfile(caregiverId: number, input: MayaProfileInput) {
  const db = await requireDb();
  let patientId: number;

  if (input.patientId) {
    const existing = await getOwnedPatient(caregiverId, input.patientId);
    if (!existing) throw new Error("Patient record was not found for this caregiver");
    patientId = existing.id;
    await db.update(patients).set({
      preferredName: input.preferredName,
      preferredLanguage: input.preferredLanguage,
      consentStatus: "confirmed",
    }).where(eq(patients.id, patientId));
  } else {
    const created = await db.insert(patients).values({
      caregiverId,
      preferredName: input.preferredName,
      preferredLanguage: input.preferredLanguage,
      consentStatus: "confirmed",
    }).$returningId();
    patientId = created[0]!.id;
  }

  const routineRows = await db.select().from(patientRoutines).where(eq(patientRoutines.patientId, patientId)).limit(1);
  const routineData = {
    morningRoutine: input.morningRoutine,
    medicineLocation: input.medicineLocation,
    approvedContent: JSON.stringify(input.approvedContent),
  };
  if (routineRows[0]) {
    await db.update(patientRoutines).set(routineData).where(eq(patientRoutines.id, routineRows[0].id));
  } else {
    await db.insert(patientRoutines).values({ patientId, ...routineData });
  }

  const existingCards = await db.select().from(gameContentCards).where(eq(gameContentCards.patientId, patientId));
  if (existingCards.length === 0) {
    await db.insert(gameContentCards).values(input.approvedContent.map(label => ({ patientId, caregiverId, category: "object" as const, label, language: input.preferredLanguage })));
  }

  return getMayaOverview(caregiverId);
}

/** Persist a completed or paused activity only after ownership is verified. */
export async function recordMayaActivity(caregiverId: number, input: MayaActivityInput) {
  const patient = await getOwnedPatient(caregiverId, input.patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  await db.insert(activityEvents).values({ ...input });
  return getMayaOverview(caregiverId);
}

export async function createMayaSupportNote(caregiverId: number, input: MayaSupportNoteInput) {
  const patient = await getOwnedPatient(caregiverId, input.patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  await db.insert(supportNotes).values({ patientId: input.patientId, authorId: caregiverId, kind: input.kind, body: input.body });
  return getMayaOverview(caregiverId);
}

export async function markMayaSupportNoteReviewed(caregiverId: number, noteId: number) {
  const db = await requireDb();
  const notes = await db.select().from(supportNotes).where(eq(supportNotes.id, noteId)).limit(1);
  const note = notes[0];
  if (!note || !(await getOwnedPatient(caregiverId, note.patientId))) {
    throw new Error("Support note was not found for this caregiver");
  }
  await db.update(supportNotes).set({ reviewed: true, reviewedAt: new Date() }).where(eq(supportNotes.id, noteId));
  return getMayaOverview(caregiverId);
}

function parseStringArray(value: string) {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) && parsed.every(item => typeof item === "string") ? parsed : [];
  } catch {
    return [];
  }
}

/** Return the full game shelf and private engagement record for the caregiver's first active profile. */
export async function getMayaPlayroom(caregiverId: number) {
  const db = await requireDb();
  const patientRows = await db.select().from(patients)
    .where(and(eq(patients.caregiverId, caregiverId), eq(patients.isArchived, false)))
    .orderBy(desc(patients.updatedAt)).limit(1);
  const patient = patientRows[0];
  if (!patient) return { patient: null, games: [], totalMemoryPoints: 0, recentSessions: [], photoChallenges: [], adaptiveRecommendations: [], contentCards: [] };

  const [progressRows, recentSessions, recentChallenges, allCameraChallenges, recommendationRows, contentCards, domainSummaries] = await Promise.all([
    db.select().from(gameProgress).where(eq(gameProgress.patientId, patient.id)),
    db.select().from(gameSessions).where(eq(gameSessions.patientId, patient.id)).orderBy(desc(gameSessions.occurredAt)).limit(18),
    db.select().from(cameraChallenges).where(eq(cameraChallenges.patientId, patient.id)).orderBy(desc(cameraChallenges.createdAt)).limit(8),
    db.select().from(cameraChallenges).where(eq(cameraChallenges.patientId, patient.id)),
    db.select().from(adaptiveGameRecommendations).where(eq(adaptiveGameRecommendations.patientId, patient.id)).orderBy(desc(adaptiveGameRecommendations.createdAt)).limit(12),
    db.select().from(gameContentCards).where(and(eq(gameContentCards.patientId, patient.id), eq(gameContentCards.isActive, true))).limit(40),
    db.select().from(domainEngagement).where(eq(domainEngagement.patientId, patient.id)),
  ]);
  const progressByGame = new Map(progressRows.map(item => [item.gameId, item]));
  const games = GAME_CATALOG.map(game => ({
    ...game,
    progress: progressByGame.get(game.id) ?? {
      id: 0, patientId: patient.id, gameId: game.id, unlockedLevel: 1, highestLevel: 1,
      memoryPoints: 0, totalSessions: 0, completedSessions: 0, consecutiveStruggles: 0, recommendedLevel: null, recommendationKind: null, lastComfortBand: null, lastPlayedAt: null,
    },
  }));

  return {
    patient,
    games,
    totalMemoryPoints: progressRows.reduce((sum, progress) => sum + progress.memoryPoints, 0) + allCameraChallenges.reduce((sum, challenge) => sum + challenge.awardedPoints, 0),
    photoQuestMemoryPoints: allCameraChallenges.reduce((sum, challenge) => sum + challenge.awardedPoints, 0),
    recentSessions,
    photoChallenges: recentChallenges.map(challenge => ({ ...challenge, targetKeywords: parseStringArray(challenge.targetKeywords) })),
    adaptiveRecommendations: recommendationRows,
    contentCards,
    domainEngagement: domainSummaries,
  };
}

/** Persist a completed game moment and adjust only the owning patient's own level and points. */
export async function recordMayaGameSession(caregiverId: number, input: MayaGameSessionInput) {
  const patient = await getOwnedPatient(caregiverId, input.patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  const bridgeRows = input.sessionKind === "bridge_assessment"
    ? await db.select().from(adaptiveGameRecommendations).where(and(eq(adaptiveGameRecommendations.patientId, input.patientId), eq(adaptiveGameRecommendations.gameId, input.gameId))).orderBy(desc(adaptiveGameRecommendations.createdAt)).limit(12)
    : [];
  const bridgeToResolve = bridgeRows.find(item => item.kind === "bridge_assessment" && item.status === "available");
  const existingRows = await db.select().from(gameProgress)
    .where(and(eq(gameProgress.patientId, input.patientId), eq(gameProgress.gameId, input.gameId))).limit(1);
  const existing = existingRows[0];
  const now = new Date();
  const resolved = resolvePlayroomProgress(existing, input);
  const outcome = resolved.outcome;
  const progressData = {
    ...resolved.next,
    lastPlayedAt: now,
  };
  if (existing) {
    await db.update(gameProgress).set(progressData).where(eq(gameProgress.id, existing.id));
  } else {
    await db.insert(gameProgress).values({ patientId: input.patientId, gameId: input.gameId, ...progressData });
  }
  await db.insert(gameSessions).values({
    patientId: input.patientId,
    gameId: input.gameId,
    level: input.level,
    score: outcome.accuracyPercent,
    possiblePoints: 20,
    correctCount: input.correctCount,
    totalItems: input.totalItems,
    hintsUsed: input.hintsUsed,
    completed: input.completed,
    durationSeconds: input.durationSeconds,
    pointsEarned: outcome.pointsEarned,
    sessionKind: input.sessionKind,
    contentSource: input.contentSource,
    comfortChoice: input.comfortChoice,
    occurredAt: now,
  });
  const recommendation = resolved.recommendation;
  await db.insert(adaptiveGameRecommendations).values({
    patientId: input.patientId,
    gameId: input.gameId,
    kind: recommendation.kind,
    currentLevel: input.level,
    recommendedLevel: recommendation.kind === "bridge_assessment" ? recommendation.lowerLevel : recommendation.nextLevel,
    lowerLevel: recommendation.kind === "bridge_assessment" ? recommendation.lowerLevel : null,
    upperLevel: recommendation.kind === "bridge_assessment" ? recommendation.upperLevel : null,
    difficultyRatioPercent: recommendation.kind === "bridge_assessment" ? Math.round(recommendation.difficultyRatio * 100) : null,
    reason: recommendation.reason,
  });
  if (bridgeToResolve) {
    await db.update(adaptiveGameRecommendations).set({ status: "completed", resolvedAt: now }).where(eq(adaptiveGameRecommendations.id, bridgeToResolve.id));
  }
  const domain = ADVANCED_GAME_CATALOG.find(game => game.id === input.gameId)?.domain;
  if (domain) {
    const domainRows = await db.select().from(domainEngagement).where(eq(domainEngagement.patientId, input.patientId));
    const existingDomain = domainRows.find(item => item.domain === domain);
    const momentsWithSupport = input.hintsUsed > 0 || input.comfortChoice !== "steady" ? 1 : 0;
    const domainData = {
      momentsCompleted: (existingDomain?.momentsCompleted ?? 0) + (input.completed ? 1 : 0),
      momentsWithSupport: (existingDomain?.momentsWithSupport ?? 0) + momentsWithSupport,
      totalParticipationPoints: (existingDomain?.totalParticipationPoints ?? 0) + outcome.pointsEarned,
      lastEngagedAt: now,
    };
    if (existingDomain) await db.update(domainEngagement).set(domainData).where(eq(domainEngagement.id, existingDomain.id));
    else await db.insert(domainEngagement).values({ patientId: input.patientId, domain, ...domainData });
  }
  await db.insert(activityEvents).values({
    patientId: input.patientId, gameId: input.gameId, templateId: "maya_playroom", level: input.level,
    language: patient.preferredLanguage, completed: input.completed, accuracyPercent: outcome.accuracyPercent,
    hintsUsed: input.hintsUsed, responseTimeSeconds: input.durationSeconds,
    frustrationFlag: input.hintsUsed >= 2 && !outcome.isStrongCompletion, mood: "engaged", syncStatus: "synced", occurredAt: now,
  });
  return { outcome, playroom: await getMayaPlayroom(caregiverId) };
}

export async function createMayaCameraChallenge(caregiverId: number, input: MayaCameraChallengeInput) {
  const patient = await getOwnedPatient(caregiverId, input.patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  const created = await db.insert(cameraChallenges).values({
    patientId: input.patientId, caregiverId, prompt: input.prompt, targetKeywords: JSON.stringify(input.targetKeywords),
  }).$returningId();
  const rows = await db.select().from(cameraChallenges).where(eq(cameraChallenges.id, created[0]!.id)).limit(1);
  return rows[0];
}

export async function getOwnedCameraChallenge(caregiverId: number, challengeId: number) {
  const db = await requireDb();
  const rows = await db.select().from(cameraChallenges)
    .where(and(eq(cameraChallenges.id, challengeId), eq(cameraChallenges.caregiverId, caregiverId))).limit(1);
  return rows[0];
}

export async function saveMayaCameraVerification(caregiverId: number, challengeId: number, result: { verified: boolean; confidencePercent: number }) {
  const challenge = await getOwnedCameraChallenge(caregiverId, challengeId);
  if (!challenge) throw new Error("Photo Quest challenge was not found for this caregiver");
  const db = await requireDb();
  const awardedPoints = result.verified ? 12 : 0;
  await db.update(cameraChallenges).set({
    status: result.verified ? "verified" : "needs_retake",
    confidencePercent: Math.max(0, Math.min(100, result.confidencePercent)),
    awardedPoints,
    imageStored: false,
    completedAt: new Date(),
  }).where(eq(cameraChallenges.id, challengeId));
  return getMayaPlayroom(caregiverId);
}

export async function getMayaAssistantHistory(caregiverId: number, patientId: number) {
  const patient = await getOwnedPatient(caregiverId, patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  return db.select().from(assistantMessages)
    .where(and(eq(assistantMessages.patientId, patientId), eq(assistantMessages.caregiverId, caregiverId)))
    .orderBy(desc(assistantMessages.createdAt)).limit(16);
}

export async function appendMayaAssistantMessage(caregiverId: number, patientId: number, role: "user" | "assistant", content: string) {
  const patient = await getOwnedPatient(caregiverId, patientId);
  if (!patient) throw new Error("Patient record was not found for this caregiver");
  const db = await requireDb();
  await db.insert(assistantMessages).values({ patientId, caregiverId, role, content });
}
