import { describe, expect, it, vi } from "vitest";

const invoke = vi.hoisted(() => vi.fn());
vi.mock("./_core/llm", () => ({ invokeLLM: invoke }));

import { createCompanionReply, verifyPhotoQuestImage } from "./mayaCompanion";

describe("MAYA companion safeguards", () => {
  it("returns a calm bounded fallback if the companion model is unavailable", async () => {
    invoke.mockRejectedValueOnce(new Error("unavailable"));
    const reply = await createCompanionReply({ preferredName: "Aita", preferredLanguage: "Assamese", approvedContent: ["mango tree"], message: "What should I do?" });
    expect(reply).toContain("Aita");
    expect(reply).toContain("small familiar step");
  });

  it("uses the structured Photo Quest result and requires sufficient confidence before awarding verification", async () => {
    invoke.mockResolvedValueOnce({ choices: [{ message: { content: JSON.stringify({ verified: true, confidencePercent: 82, response: "I can see a mango tree." }) } }] });
    const result = await verifyPhotoQuestImage({ prompt: "Find a mango tree", targetKeywords: ["mango", "tree"], imageDataUrl: "data:image/jpeg;base64,aGVsbG8=" });
    expect(result).toEqual({ verified: true, confidencePercent: 82, response: "I can see a mango tree." });
  });

  it("does not verify an uncertain image even if a model marks it true", async () => {
    invoke.mockResolvedValueOnce({ choices: [{ message: { content: JSON.stringify({ verified: true, confidencePercent: 45, response: "Please take another look." }) } }] });
    const result = await verifyPhotoQuestImage({ prompt: "Find a mango tree", targetKeywords: ["mango", "tree"], imageDataUrl: "data:image/jpeg;base64,aGVsbG8=" });
    expect(result.verified).toBe(false);
    expect(result.confidencePercent).toBe(45);
  });
});
