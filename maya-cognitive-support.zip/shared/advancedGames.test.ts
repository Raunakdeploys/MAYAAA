import { describe, expect, it } from "vitest";
import { ADVANCED_GAME_CATALOG, CORE_LEVEL_COUNT, getAdvancedLevelSpec, recommendNextAdaptiveExperience } from "./advancedGames";

describe("MAYA advanced game system", () => {
  it("provides six differentiated game genres with twenty standard levels each", () => {
    expect(ADVANCED_GAME_CATALOG).toHaveLength(6);
    expect(CORE_LEVEL_COUNT).toBe(20);
    expect(new Set(ADVANCED_GAME_CATALOG.map(game => game.genre)).size).toBe(6);
    ADVANCED_GAME_CATALOG.forEach(game => expect(game.bands.flatMap(band => Array.from({ length: band.levels[1] - band.levels[0] + 1 }, (_, index) => index + band.levels[0]))).toHaveLength(20));
  });

  it("increases demands gradually while preserving support in every twenty-level game", () => {
    ADVANCED_GAME_CATALOG.forEach(game => {
      const first = getAdvancedLevelSpec(game.id, 1);
      const middle = getAdvancedLevelSpec(game.id, 10);
      const final = getAdvancedLevelSpec(game.id, 20);
      expect(middle.targetCount).toBeGreaterThanOrEqual(first.targetCount);
      expect(final.targetCount).toBeGreaterThanOrEqual(middle.targetCount);
      expect(final.recallSpan).toBeGreaterThanOrEqual(middle.recallSpan);
      expect(final.cueBudget).toBeGreaterThan(0);
    });
  });

  it("offers a bridge assessment after repeated difficulty rather than punishing or skipping the person forward", () => {
    const recommendation = recommendNextAdaptiveExperience({ level: 5, accuracyPercent: 42, hintsUsed: 3, completed: true, consecutiveStruggles: 2 });
    expect(recommendation).toEqual(expect.objectContaining({ kind: "bridge_assessment", lowerLevel: 4, upperLevel: 5, difficultyRatio: 0.5 }));
  });

  it("advances only a comfortable completion and otherwise keeps or gently lowers difficulty", () => {
    expect(recommendNextAdaptiveExperience({ level: 8, accuracyPercent: 95, hintsUsed: 0, completed: true, consecutiveStruggles: 0 })).toEqual(expect.objectContaining({ kind: "advance", nextLevel: 9 }));
    expect(recommendNextAdaptiveExperience({ level: 8, accuracyPercent: 70, hintsUsed: 2, completed: true, consecutiveStruggles: 0 })).toEqual(expect.objectContaining({ kind: "repeat_with_new_content", nextLevel: 8 }));
    expect(recommendNextAdaptiveExperience({ level: 8, accuracyPercent: 45, hintsUsed: 1, completed: true, consecutiveStruggles: 0 })).toEqual(expect.objectContaining({ kind: "gentler_choice", nextLevel: 7 }));
  });
});
