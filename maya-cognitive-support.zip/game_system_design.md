# MAYA Advanced Game System

## Principle

MAYA will provide **six differentiated, long-form cognitive-stimulation games**, each with twenty standard levels. The experience uses caregiver-approved people, objects, places, routines, languages, and family prompts. It does not present game performance as a cognitive-health measure or promise improvement.

| Game | Genre | Activity focus | Personalisation | Twenty-level arc |
|---|---|---|---|---|
| Memory Mosaic | Visual association studio | Familiar visual relationships | People, objects, places | Pairs → scenes → meaningful alternatives → four-part mosaics |
| Lantern Echo | Rhythm and sequence recall | Working memory and paced sequence recall | Sounds, colours, landmarks | Two-step glow → crossroad sequence → seven-step homeward path |
| Routine Studio | Practical planning | Everyday sequencing and prioritisation | Approved routine and supports | Next step → morning routine → flexible day story |
| Market Detective | Selective-attention scavenger | Target selection with gentle distractors | Foods, objects, market memories | One target → basket → list → four-item market day |
| Story Garden | Language and reminiscence | Word, image, sound, and gentle story connection | Names, language, sayings, prompts | Name → sound → phrase → four-part story |
| Village Navigator | Spatial route-building | Landmark recognition and illustrated route planning | Home landmarks and familiar places | Landmark → route → four-stop village story |

## Adaptive bridge system

When a person completes a level comfortably—with strong accuracy and little support—the next standard level opens. A middling or supported completion repeats the same level with fresh approved content. When two sessions show repeated difficulty near a boundary, MAYA offers a **bridge assessment** halfway between the adjacent levels. This reduces one visible demand, preserves the same genre, and increases cues; success determines whether the next experience repeats the upper level or continues with a gentler version. It is a usability mechanism, not a test of ability or clinical status.

## Evidence-informed metrics

Caregivers see recent activity, chosen genres, cue use, pauses, optional bridge recommendations, and personal-content preferences. They do not see a dementia score, health prediction, “brain age,” or diagnostic trend. Memory points remain optional in-game recognition of participation.

## Safety and accessibility

Every level preserves a visible back route, pause, replay, spoken support, one action at a time, and no countdown. A wrong answer triggers a supportive explanation and available cue—not point loss or a “failure” state. See [research notes](./research_notes_advanced.md) for the evidence framing and sources.
