# MAYA Design Directions

## Three directions considered

### 1. Home Rituals

**Very Brief Intro:** A calm domestic interface inspired by the rhythm of a well-kept home: woven borders, ceramic color, remembered objects, and quiet reassurance. It feels familiar before it feels technical.

**Probability:** 0.07

### 2. Lantern Path

**Very Brief Intro:** A gentle navigation metaphor built around a soft lantern traveling along a daily path. It emphasizes orientation, steps, and ongoing care without clinical visual language.

**Probability:** 0.04

### 3. Quiet Atlas

**Very Brief Intro:** An editorial, map-inspired world that connects people, places, and routines through illustrated landmarks. It treats memory as a landscape rather than a score.

**Probability:** 0.09

## Chosen Direction: Home Rituals

### Design Movement

**Contemporary craft modernism** with regional North-Eastern Indian textile cues. This direction uses humane editorial composition and tactile details to make a digital support tool feel like a familiar household object rather than a clinical instrument.

### Core Principles

1. **Dignity before diagnosis.** Every screen affirms participation and avoids rankings, failure states, urgency colors, or medicalized scores.
2. **Familiarity guides attention.** Objects, language, and visual rhythm suggest home routines, so the interface feels learned rather than deciphered.
3. **One calm decision at a time.** Patient views use generous touch targets and a single clear primary action; caregiver views surface context without noise.
4. **Warm utility, never ornament for ornament’s sake.** Texture and illustration convey place and care, while contrast, spacing, and large type preserve accessibility.

### Color Philosophy

The interface is grounded in **warm rice-paper cream** so it feels quiet and daylight-readable. **Deep indigo** carries trusted actions and anchoring information, while **river teal** signals calm support and voice connection. **Brass yellow** gently marks reminders, not warnings. A restrained **clay terracotta** provides human warmth and cultural specificity in small, memorable moments. Contrast must remain robust, particularly on patient-facing controls.

### Layout Paradigm

The experience follows a **home-to-horizon rhythm** rather than a centered dashboard grid. Patient screens arrange content like a familiar tabletop: a welcome moment, one main action, and a handrail of support nearby. Caregiver screens use a grounded left rail and a more spacious reporting field, with an illustrated thread visually linking activity to reflection.

### Signature Elements

1. A repeating **bamboo-line frame** appears as a subtle structural border and progress track.
2. A **compass balance** expresses support without ranking or clinical judgment.
3. A small **house-and-path symbol** anchors the MAYA mark and session journey.

### Interaction Philosophy

Every interaction should answer: “Does this make the next step feel safer?” Taps receive a quiet physical response, choices never turn red, and additional assistance appears progressively rather than as correction. The system saves activity locally and visibly reassures the user that the moment has been kept safely.

### Animation

Use short, quiet motion only: buttons compress slightly on press; cards rise 2px on hover; content enters with a 180–240ms opacity and upward drift; the progress compass settles with a soft 250ms rotation. No flashing, bouncing loops, timers, or celebratory confetti. Respect reduced-motion settings.

### Typography System

**Fraunces** provides a warm, distinguished display voice for greetings and completion moments. **Noto Sans** serves all functional text because it supports Indian-language expansion and remains exceptionally legible at large scale. Patient-facing headings begin at 30–36px; interaction labels are 18–22px with strong weight and generous line height. Avoid compressed text and all-caps except compact status labels.

### Brand Essence

**MAYA is a personalized cognitive-support companion that turns a person’s own routine, people, and place into gentle daily practice.**

Personality: **reassuring, rooted, respectful.**

### Brand Voice

Headlines sound like a trusted family member: present, specific, and unhurried. CTAs name the next caring action rather than a generic product action. Microcopy reassures without patronizing.

> “Let’s begin with a familiar step.”

> “Your day has been saved safely on this device.”

### Wordmark & Logo

The MAYA mark is a simple indigo house silhouette held within a rounded path-loop, with a tiny terracotta sun at its threshold. It suggests home, memory, and a way forward without relying on a literal brain icon. The wordmark uses a high-contrast, quietly distinctive serif treatment rather than a default sans-serif label.

### Signature Brand Color

**Maya Indigo — #27326B.** A deep, quiet blue that communicates stability and becomes the visual anchor across patient and caregiver contexts.

## Style Decisions

- Patient cards use broad cream surfaces, large labels, and generous vertical breathing room; caregiver analytics remain structured but never dense.
- Generated visuals may support context, but all task-critical imagery must remain deterministic in the user interface.
- No generic stock imagery, leaderboards, competitive gamification, alarming red errors, countdowns, or claims of cognitive improvement.
- **Accepted review amendment:** The bamboo-line motif is MAYA’s primary structural language. It is expressed as a woven path/frame system in the tablet border, section dividers, activity journey, and support handrail; it must not read as a generic dotted rule.
- **Accepted review amendment:** The indigo house-and-path symbol pairs with a high-contrast serif MAYA wordmark, making the companion feel like a crafted household presence rather than a generic app header.
- **Accepted review amendment:** Patient-facing choices use caring ritual language that identifies the next safe step, such as “Begin a familiar step,” instead of generic software commands.

## Hackathon Demo Expansion: The MAYA Playroom

### Product Promise

MAYA Playroom turns caregiver-approved people, objects, places, and routines into short, **playful engagement moments**. It is a supportive experience—not a diagnostic instrument, treatment, clinical assessment, or measure of cognitive ability. The app records participation and self-contained game results for the caregiver account; it never infers disease progression or gives medical advice.

### Six Playable Game Systems

Each game has ten algorithmically generated levels. Levels change only one complexity dimension at a time, begin with a practice round, allow repeat attempts, and offer a spoken hint. “Memory points” reward completing a moment; an incorrect choice never removes accumulated points.

1. **Pairing Table:** reveal and match familiar objects with a progressively larger card set.
2. **Lantern Path:** repeat a short, highlighted path of colours and shapes, growing by one step per level.
3. **Daily Order:** arrange a small routine in a familiar sequence using large, numbered choices.
4. **Market Basket:** select the requested everyday objects from a calm visual grid.
5. **Word Garden:** connect a familiar picture to its beginning sound or word label.
6. **Village Map:** remember where a gentle illustrated landmark appeared, moving from two to six locations.

### Adaptive Rules

The app starts at Level 1 for a new game. A high-confidence completion advances one level, while a second attempt or hint maintains the current level. Repeated difficulty shows a suggested rest message rather than a penalty. Caregivers can explicitly reset a game level. Game mechanics are deterministic and offline-ready; the AI assistant is never responsible for scoring a core game.

### Camera Challenge: Photo Quest

Photo Quest is a separate, caregiver-approved activity. A caregiver chooses an object or place prompt, such as “a mango tree,” and the patient sees a clear consent notice before opening the mobile camera. MAYA uses the browser camera only after a direct tap, captures one image, submits it for a visual similarity check, stores only the result by default, and offers a retake when confidence is low. It avoids face-recognition prompts, background surveillance, and automatic camera activation. A mismatch earns no point but never removes points.

### AI Companion Boundary

The assistant speaks in short, warm, non-medical language. It can repeat an approved instruction, offer a game hint, summarize a saved session, or guide the caregiver through setup. It must never diagnose, speculate about decline, override caregiver-approved content, invent personal memories, or provide emergency/clinical advice. Voice input is optional and clearly indicated; text remains available at every moment.
